"""
Central configuration for PhyTM
===============================
Defines the experiment Config dataclass (all hyper-parameters in one place),
the benchmark grid, and the dataset/seq_len adaptive policy. The numeric
behaviour of the adaptive helpers is identical to the original training script
so results remain reproducible.
"""
from dataclasses import dataclass, replace
from typing import Optional
import math


# ── benchmark grid ────────────────────────────────────────────────
DATASETS = [
    "ETTh1", "ETTh2", "ETTm1", "ETTm2",
    "weather", "exchange_rate", "electricity", "traffic",
]
PRED_LENS = [96, 192, 336, 720]
SEQ_LEN   = 96

# ── ablation cases (paper RQ3) ────────────────────────────────────
#   full          DMD + Phys-Transformer + Phys-Mamba (complete PhyTM)
#   phys_none     no physics in either path (both degenerate to standard)
#   phys_no_mamba physics in the Transformer only
#   phys_no_trans physics in the Mamba only
#   no_text/no_image/no_num   remove one modality path
ABLATION_CASES = [
    "full",
    "phys_none", "phys_no_mamba", "phys_no_trans",
    "no_text", "no_image", "no_num",
]


@dataclass
class Config:
    # ── data ──────────────────────────────────────────────────────
    data_root: str = "/home/zc/cwx/data"
    dataset:   str = "ETTh1"
    features:  str = "M"
    seq_len:   int = 96
    pred_len:  int = 96
    # ── model ─────────────────────────────────────────────────────
    patch_len:      int = 16
    patch_stride:   int = 8
    img_patch:      int = 16
    img_size:       Optional[int] = None
    d_model:        int = 64
    d_state:        int = 16
    n_text_layers:  int = 2
    n_image_layers: int = 1
    n_cross_layers: int = 1
    n_gtm_layers:   int = 1
    n_heads:        int = 8
    # ── DMD physics extraction ────────────────────────────────────
    n_modes:       int = 8
    dmd_embed_len: int = 8
    dmd_rank:      Optional[int] = None
    dmd_delta_t:   float = 1.0
    lambda_phys:   float = 1e-3
    dropout:       float = 0.1
    # ── textual path / GPT-2 ──────────────────────────────────────
    gpt2_path:      str = "/home/zc/cwx/model/gpt2/"
    max_prompt_len: int = 80
    use_gpt2:       bool = True
    # ── training ──────────────────────────────────────────────────
    batch_size:    int = 16
    lr:            float = 1e-4
    weight_decay:  float = 1e-4
    epochs:        int = 30
    patience:      int = 8
    min_epochs:    int = 10
    grad_clip:     float = 1.0
    num_workers:   int = 0
    device:        str = "cuda"
    seed:          int = 2024
    save_dir:      str = "./checkpoints_benchmark"
    # ── seq_len adaptive training ─────────────────────────────────
    warmup_epochs: int = 0
    no_lr_scale:   bool = False
    # ── ablation (RQ3) ────────────────────────────────────────────
    ablation:      str = "full"
    # ── logging ───────────────────────────────────────────────────
    verbose:       bool = False

    def copy(self, **changes) -> "Config":
        return replace(self, **changes)


@dataclass
class Adapted:
    """Effective hyper-parameters after the dataset/seq_len adaptive policy."""
    d_model:       int
    n_text_layers: int
    n_gtm_layers:  int
    dropout:       float
    weight_decay:  float
    lambda_phys:   float
    batch_size:    int
    warmup_epochs: int
    lr:            float
    note:          str = ""


def adapt(cfg: Config, n_channels: int) -> Adapted:
    """Apply the dataset/seq_len adaptive policy (identical numerics to the
    original training script). Returns the effective hyper-parameters.

    The dataset-size branch is an elif chain keyed on the channel count C, with
    name-based branches for non-stationary (exchange_rate) and low-sample
    (national_illness) datasets.
    """
    C = n_channels
    ds = cfg.dataset.lower()

    d_model     = cfg.d_model
    n_text      = cfg.n_text_layers
    n_gtm       = cfg.n_gtm_layers
    dropout     = cfg.dropout
    weight_decay = cfg.weight_decay
    lambda_phys = cfg.lambda_phys
    note = ""

    if C >= 500:
        d_model = min(cfg.d_model, 48); n_text = 1; n_gtm = 1
        dropout = max(cfg.dropout, 0.3); weight_decay = cfg.weight_decay * 4
        note = (f"traffic C={C} -> d={d_model} n_text={n_text} "
                f"dropout={dropout:.1f} wd={weight_decay:.1e}")
    elif C >= 300:
        d_model = min(cfg.d_model, 48); n_text = 1; n_gtm = 1
        dropout = max(cfg.dropout, 0.3); weight_decay = cfg.weight_decay * 4
        note = (f"electricity C={C} -> d={d_model} "
                f"dropout={dropout:.1f} wd={weight_decay:.1e}")
    elif C >= 20:
        dropout = max(cfg.dropout, 0.2); weight_decay = cfg.weight_decay * 2
        note = f"weather C={C} -> dropout={dropout:.1f} wd={weight_decay:.1e}"
    elif 'exchange' in ds:
        lambda_phys = 0.0; weight_decay = cfg.weight_decay * 0.5
        note = f"exchange_rate non-stationary -> lambda_phys=0 wd={weight_decay:.1e}"
    elif 'illness' in ds:
        d_model = min(cfg.d_model, 32); n_text = 1; n_gtm = 1
        dropout = max(cfg.dropout, 0.3); weight_decay = cfg.weight_decay * 8
        note = (f"illness few samples -> d={d_model} "
                f"dropout={dropout:.1f} wd={weight_decay:.1e}")

    # effective batch size (clamp very wide multivariate batches)
    batch_size = cfg.batch_size
    if cfg.features == 'M' and C * cfg.batch_size > 1024:
        batch_size = max(8, 1024 // C)

    # auto warmup for long lookback windows
    warmup_epochs = cfg.warmup_epochs
    if warmup_epochs == 0 and cfg.seq_len >= 192:
        warmup_epochs = 3

    # seq_len LR scaling (compensates the larger effective LR of long sequences)
    lr = cfg.lr
    if not cfg.no_lr_scale and cfg.seq_len != 96:
        lr = cfg.lr * math.sqrt(96.0 / cfg.seq_len)

    return Adapted(
        d_model=d_model, n_text_layers=n_text, n_gtm_layers=n_gtm,
        dropout=dropout, weight_decay=weight_decay, lambda_phys=lambda_phys,
        batch_size=batch_size, warmup_epochs=warmup_epochs, lr=lr, note=note,
    )


def apply_ablation(cfg: Config):
    """Translate an ablation case name into the four model switches.

    Returns (enable_text, enable_image, enable_num, phys_text, phys_image).
    """
    en_text = en_image = en_num = True
    ph_text = ph_image = True
    case = cfg.ablation
    if   case == 'full':          pass
    elif case == 'phys_none':     ph_text = ph_image = False
    elif case == 'phys_no_mamba': ph_image = False
    elif case == 'phys_no_trans': ph_text  = False
    elif case == 'no_text':       en_text  = False
    elif case == 'no_image':      en_image = False
    elif case == 'no_num':        en_num   = False
    else:
        raise ValueError(f"unknown ablation case: {case!r}")
    return en_text, en_image, en_num, ph_text, ph_image
