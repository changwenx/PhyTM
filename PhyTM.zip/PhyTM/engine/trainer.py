"""
Training / validation / testing engine for PhyTM
=================================================
``run_experiment(cfg)`` runs one full train -> validate -> test cycle for a
single (dataset, pred_len) setting and returns a result dictionary. It is the
single entry point used by ``run_benchmark.py``; calling it in-process (rather
than spawning a subprocess) means the caller fully controls console output.

By default the engine is quiet: it prints only one line per epoch
(epoch / train loss / validation MSE+MAE) and one final ``[Test]`` line with
the test MSE/MAE. Every other diagnostic (device, data split, distribution
statistics, the adaptive policy, the ablation switches, optimiser layout,
per-epoch physics-spectrum monitoring, val/test gap analysis) is emitted only
when ``cfg.verbose`` is set.

Training objective (paper section "Training Objective"):
    L = L_pred + lambda_phys * L_phys
where L_phys = ||Delta alpha||^2 + ||Delta omega||^2 regularises the learnable
residuals of the DMD spectrum. The forecasting term here uses a frequency-plus-
time MAE surrogate with arctan-decaying per-horizon weights for training, while
validation and test are scored with pure MSE/MAE to match the reported metrics.
"""

import os
import gc
import math
import time

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import LambdaLR

from models import PhyTM, set_verbose, is_verbose
from data import TimeSeriesDataset
from config import Config, adapt, apply_ablation


# ──────────────────────────────────────────────────────────────────
#   helpers
# ──────────────────────────────────────────────────────────────────
def metric(pred: np.ndarray, true: np.ndarray):
    """Return (MSE, MAE). Some code bases return (MAE, MSE); mind the order
    when comparing numbers across repositories."""
    mse = float(np.mean((pred - true) ** 2))
    mae = float(np.mean(np.abs(pred - true)))
    return mse, mae


def build_scheduler(optimizer, warmup_epochs: int, total_epochs: int):
    """Warmup + cosine schedule.

    For the first ``warmup_epochs`` the learning rate rises linearly from
    0.1x to 1.0x of the base LR; afterwards it follows a cosine decay to 0.
    Implemented as a multiplicative factor via ``LambdaLR`` (``ep`` starts at 0
    because ``scheduler.step()`` is called at the end of each epoch).
    """
    cosine_epochs = max(1, total_epochs - warmup_epochs)

    def lr_lambda(ep):
        if ep < warmup_epochs:
            return 0.1 + 0.9 * ep / max(1, warmup_epochs - 1)
        progress = (ep - warmup_epochs) / cosine_epochs
        return max(0.0, 0.5 * (1.0 + math.cos(math.pi * progress)))

    return LambdaLR(optimizer, lr_lambda)


# ──────────────────────────────────────────────────────────────────
#   one full experiment
# ──────────────────────────────────────────────────────────────────
def run_experiment(cfg: Config, ckpt_path: str = None) -> dict:
    """Run one (dataset, pred_len) experiment end-to-end.

    Returns a dict with keys:
        dataset, seq_len, pred_len, val_MSE, test_MSE, test_MAE,
        n_channels, elapsed_s, status
    ``status`` is "ok" on success; on a handled failure the function raises,
    and the benchmark driver records the error per run.
    """
    set_verbose(cfg.verbose)

    torch.manual_seed(cfg.seed)
    np.random.seed(cfg.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(cfg.seed)

    device = torch.device(cfg.device if torch.cuda.is_available() else 'cpu')
    os.makedirs(cfg.save_dir, exist_ok=True)
    if is_verbose():
        print(f"[Device] {device}")

    t_start = time.time()

    # ── data ───────────────────────────────────────────────────────
    kw = dict(root=cfg.data_root, dataset=cfg.dataset,
              seq_len=cfg.seq_len, pred_len=cfg.pred_len,
              features=cfg.features)
    train_set = TimeSeriesDataset(flag='train', **kw)
    val_set   = TimeSeriesDataset(flag='val',   **kw)
    test_set  = TimeSeriesDataset(flag='test',  **kw)
    C = train_set.n_channels
    n_vars = C if cfg.features == 'M' else 1

    if is_verbose():
        print(f"[Data] {cfg.dataset} ({cfg.features}, C={C})  "
              f"train/val/test = {len(train_set)}/{len(val_set)}/{len(test_set)}")
        print(f"[Split] train mean={train_set.mean.mean():.4f}  "
              f"std={train_set.std.mean():.4f}")
        # val/test reuse the train mean/std -> identical normalisation space
        assert np.allclose(train_set.mean, val_set.mean, atol=1e-5), \
            "val mean != train mean -- inconsistent normalisation space!"
        assert np.allclose(train_set.mean, test_set.mean, atol=1e-5), \
            "test mean != train mean -- inconsistent normalisation space!"
        print(f"[Split] val/test normalised with train statistics (no leakage)")
        tr_d, va_d, te_d = train_set.data, val_set.data, test_set.data
        print(f"[Distribution] train: mu={tr_d.mean():.4f} sigma={tr_d.std():.4f}  "
              f"val: mu={va_d.mean():.4f} sigma={va_d.std():.4f}  "
              f"test: mu={te_d.mean():.4f} sigma={te_d.std():.4f}")

    # ── dataset / seq_len adaptive policy (identical numerics) ───────
    ad = adapt(cfg, C)
    if is_verbose() and ad.note:
        print(f"[Adaptive] {ad.note}")

    # ── model (built before init_from_data, which needs an SVD pass) ──
    model = PhyTM(
        seq_len=cfg.seq_len,       pred_len=cfg.pred_len,
        n_vars=n_vars,
        patch_len=cfg.patch_len,   patch_stride=cfg.patch_stride,
        img_patch=cfg.img_patch,   img_size=cfg.img_size,
        d_model=ad.d_model,        d_fused=ad.d_model,
        d_state=cfg.d_state,
        n_text_layers=ad.n_text_layers,
        n_image_layers=cfg.n_image_layers,
        n_cross_layers=cfg.n_cross_layers,
        n_gtm_layers=ad.n_gtm_layers,
        n_heads=cfg.n_heads,
        n_modes=cfg.n_modes,
        dmd_embed_len=cfg.dmd_embed_len,
        dmd_rank=cfg.dmd_rank,
        dmd_delta_t=cfg.dmd_delta_t,
        dropout=ad.dropout,
        gpt2_path=cfg.gpt2_path,
        max_prompt_len=cfg.max_prompt_len,
        use_gpt2=cfg.use_gpt2,
        dataset=cfg.dataset,
    ).to(device)

    # ── ablation switches (paper RQ3) ────────────────────────────────
    en_text, en_image, en_num, ph_text, ph_image = apply_ablation(cfg)
    model.enable_text  = en_text
    model.enable_image = en_image
    model.enable_num   = en_num
    model.text_encoder.use_phys  = ph_text
    model.image_encoder.use_phys = ph_image
    if is_verbose():
        print(f"[Ablation] case='{cfg.ablation}'  paths(text/img/num)="
              f"{int(en_text)}/{int(en_image)}/{int(en_num)}  "
              f"phys(trans/mamba)={int(ph_text)}/{int(ph_image)}")

    n_param = sum(p.numel() for p in model.parameters() if p.requires_grad)

    # ── DMD precompute (on CPU to avoid polluting the CUDA context) ──
    model.phy_extractor.init_from_data(train_set, n_samples=512, device='cpu')
    model.phy_extractor.base_alpha.data = model.phy_extractor.base_alpha.data.to(device)
    model.phy_extractor.base_omega.data = model.phy_extractor.base_omega.data.to(device)

    # ── data loaders (built after init_from_data) ────────────────────
    use_pin = (device.type == 'cuda')

    def make_loader(ds, shuffle):
        return DataLoader(ds, batch_size=ad.batch_size, shuffle=shuffle,
                          num_workers=cfg.num_workers, drop_last=shuffle,
                          pin_memory=use_pin,
                          persistent_workers=(cfg.num_workers > 0))

    train_loader = make_loader(train_set, True)
    val_loader   = make_loader(val_set,  False)
    test_loader  = make_loader(test_set, False)

    if is_verbose():
        n_patches_num = getattr(model.num_path, 'n_patches', '?')
        n_patches_img = model.image_encoder.n_patches
        print(f"[Model] params={n_param/1e6:.2f}M  num_patches={n_patches_num}  "
              f"img_patches={n_patches_img}  warmup={ad.warmup_epochs}ep  "
              f"lr={ad.lr:.2e}  gtm_layers={ad.n_gtm_layers}")
        if ad.warmup_epochs and cfg.warmup_epochs == 0:
            print(f"[Auto warmup] seq_len={cfg.seq_len} >= 192 -> "
                  f"{ad.warmup_epochs} warmup epochs enabled")
        if not cfg.no_lr_scale and cfg.seq_len != 96:
            scale = math.sqrt(96.0 / cfg.seq_len)
            print(f"[LR Scale] seq_len={cfg.seq_len} -> "
                  f"lr {cfg.lr:.2e} x {scale:.3f} = {ad.lr:.2e}")

    # ── optimiser: physics parameters get a much larger LR ───────────
    # delta_alpha / delta_omega / bias_scale receive tiny gradients (diluted
    # by softmax), so a 100x LR lifts their update magnitude into a useful
    # range; text_gate gets 0.1x to avoid competing with the physics gradients.
    phy_params, text_gate_params, other_params = [], [], []
    for name, p in model.named_parameters():
        if 'delta_alpha' in name or 'delta_omega' in name or '_bias_scale_raw' in name:
            phy_params.append(p)
        elif 'text_gate' in name:
            text_gate_params.append(p)
        else:
            other_params.append(p)
    phy_lr       = ad.lr * 100
    text_gate_lr = ad.lr * 0.1
    opt_groups = [
        {'params': other_params, 'lr': ad.lr},
        {'params': phy_params,   'lr': phy_lr, 'weight_decay': 0.0},
    ]
    if text_gate_params:
        opt_groups.append(
            {'params': text_gate_params, 'lr': text_gate_lr, 'weight_decay': 0.0})
    opt = torch.optim.AdamW(opt_groups, weight_decay=ad.weight_decay)
    if is_verbose():
        print(f"[Optimizer] main lr={ad.lr:.2e}  physics lr={phy_lr:.2e}  "
              f"text_gate lr={text_gate_lr:.2e}  physics params={len(phy_params)}")

    sched = build_scheduler(opt, ad.warmup_epochs, cfg.epochs)

    crit_mse = nn.MSELoss()
    crit_mae = nn.L1Loss()

    # arctan-decaying per-horizon weights (cf. MDMLP-EIA): near steps weigh more
    #   w[h] = -arctan(h+1) + pi/4 + 1  (step 1 ~ 1.2, step 96 ~ 0.2)
    train_ratio = torch.tensor(
        [-math.atan(h + 1) + math.pi / 4 + 1 for h in range(cfg.pred_len)],
        device=device, dtype=torch.float32,
    ).unsqueeze(-1)                                                  # [H, 1]

    def joint_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """0.8 x frequency-domain MAE + 0.2 x time-domain MAE, with the arctan
        decaying horizon weights. Validation uses pure MSE to match evaluation.
        pred/target: [B, H, C]."""
        w = train_ratio.unsqueeze(0)                                # [1, H, 1]
        p_w = pred * w
        t_w = target * w
        l_mae = crit_mae(p_w, t_w)
        pf = torch.fft.rfft(p_w, dim=1, norm='ortho')
        tf = torch.fft.rfft(t_w, dim=1, norm='ortho')
        l_freq = (pf - tf).abs().mean()
        return 0.8 * l_freq + 0.2 * l_mae

    ckpt = ckpt_path or os.path.join(
        cfg.save_dir,
        f"{cfg.dataset}_{cfg.features}_sl{cfg.seq_len}_pl{cfg.pred_len}.pt")
    best_val, bad_ep, have_ckpt = float('inf'), 0, False

    # ── training loop ────────────────────────────────────────────────
    for ep in range(1, cfg.epochs + 1):
        t0 = time.time()
        model.train()
        tr_loss = n_seen = n_skip = 0

        for x, y, stats, idx in train_loader:
            x, y = x.to(device), y.to(device)
            stats, idx = stats.to(device), idx.to(device)
            opt.zero_grad()
            pred = model(x)
            loss = joint_loss(pred, y)
            # physics regulariser L_phys = ||Delta alpha||^2 + ||Delta omega||^2
            if ad.lambda_phys > 0:
                loss = loss + ad.lambda_phys * model.physics_regularization()
            if not torch.isfinite(loss):
                n_skip += 1
                continue
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            if not torch.isfinite(norm):
                opt.zero_grad()
                n_skip += 1
                continue
            opt.step()
            tr_loss += loss.item() * x.size(0)
            n_seen  += x.size(0)
        tr_loss /= max(n_seen, 1)

        # ── validation (pure MSE/MAE) ────────────────────────────────
        model.eval()
        vl, vl_mae, nv = 0.0, 0.0, 0
        with torch.no_grad():
            for x, y, stats, idx in val_loader:
                x, y = x.to(device), y.to(device)
                stats, idx = stats.to(device), idx.to(device)
                pred_v = model(x, sample_idx=idx, stats=stats)
                v = crit_mse(pred_v, y)
                if torch.isfinite(v):
                    vl     += v.item() * x.size(0)
                    vl_mae += crit_mae(pred_v, y).item() * x.size(0)
                    nv     += x.size(0)
        vl     = vl     / max(nv, 1) if nv else float('inf')
        vl_mae = vl_mae / max(nv, 1) if nv else float('inf')
        sched.step()

        skip_s = f"  skip={n_skip}" if n_skip else ""
        print(f"Epoch {ep:>3}/{cfg.epochs} | train {tr_loss:.4f} | "
              f"val MSE {vl:.4f}  MAE {vl_mae:.4f}{skip_s}")

        # ── per-epoch physics-spectrum monitoring (verbose only) ──────
        if is_verbose():
            with torch.no_grad():
                ba = model.phy_extractor.base_alpha.cpu()
                bw = model.phy_extractor.base_omega.cpu()
                da = model.phy_extractor.delta_alpha.cpu()
                dw = model.phy_extractor.delta_omega.cpu()
                bs = model.text_encoder.bias_scale.cpu().item()
                print(f"  [Physics] ||Da||={da.norm():.4f}  ||Dw||={dw.norm():.4f}  "
                      f"bias_scale={bs:.4f}")
                top = min(3, da.numel())
                vals = "  ".join(
                    f"k{i}:(base={ba[i]:+.3f}+D={da[i]:+.3f}={ba[i]+da[i]:+.3f}, "
                    f"w={bw[i]+dw[i]:+.3f})"
                    for i in range(top))
                print(f"  [Physics] {vals}")
            if ep == 1:
                ga = model.phy_extractor.delta_alpha.grad
                gw = model.phy_extractor.delta_omega.grad
                gb = model.text_encoder._bias_scale_raw.grad
                if ga is not None:
                    gb_val = f"{gb.item():.4f}" if gb is not None else "None"
                    print(f"  [Physics] grad ||dDa||={ga.norm():.4f}  "
                          f"||dDw||={gw.norm():.4f}  dbias_scale={gb_val}  "
                          f"-> physics parameters are being trained")
                else:
                    print(f"  [Physics] grad=None -- physics parameters received "
                          f"no gradient")

        # protection window: for the first min_epochs only record the best,
        # do not count bad epochs; afterwards apply early stopping on val MSE.
        if math.isfinite(vl) and vl < best_val:
            best_val = vl
            torch.save(model.state_dict(), ckpt)
            have_ckpt = True
            bad_ep = 0
        elif ep <= cfg.min_epochs:
            if not have_ckpt:
                torch.save(model.state_dict(), ckpt)
                have_ckpt = True
        else:
            bad_ep += 1
            if bad_ep >= cfg.patience:
                if is_verbose():
                    print(f"[EarlyStop] patience={cfg.patience}")
                break

    if not have_ckpt:
        raise RuntimeError("no checkpoint was saved (validation never finite)")

    # ── test ─────────────────────────────────────────────────────────
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    preds, trues = [], []
    with torch.no_grad():
        for x, y, stats, idx in test_loader:
            x = x.to(device)
            stats, idx = stats.to(device), idx.to(device)
            preds.append(model(x, sample_idx=idx, stats=stats).cpu().numpy())
            trues.append(y.numpy())
    preds, trues = np.concatenate(preds), np.concatenate(trues)
    mse, mae = metric(preds, trues)
    print(f"[Test] {cfg.dataset} sl={cfg.seq_len} pl={cfg.pred_len}  "
          f"MSE={mse:.4f}  MAE={mae:.4f}")

    # ── val/test gap analysis (verbose only) ─────────────────────────
    if is_verbose():
        gap = mse - best_val
        ratio = mse / max(best_val, 1e-8)
        print(f"[Gap Analysis] best_val_MSE={best_val:.4f}  test_MSE={mse:.4f}  "
              f"gap={gap:+.4f}  ratio={ratio:.3f}x")
        if mse > best_val * 1.15:
            va_m, va_s = val_set.data.mean(),  val_set.data.std()
            te_m, te_s = test_set.data.mean(), test_set.data.std()
            print(f"  distribution shift: val mu={va_m:.4f} sigma={va_s:.4f} | "
                  f"test mu={te_m:.4f} sigma={te_s:.4f} | "
                  f"|Dmu|={abs(te_m - va_m):.4f}  |Dsigma|={abs(te_s - va_s):.4f}")

    elapsed = time.time() - t_start

    # free the model / CUDA cache before returning
    del model, opt, sched, train_loader, val_loader, test_loader
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    gc.collect()

    return dict(
        dataset=cfg.dataset, seq_len=cfg.seq_len, pred_len=cfg.pred_len,
        n_channels=C, val_MSE=best_val, test_MSE=mse, test_MAE=mae,
        elapsed_s=elapsed, status="ok",
    )
