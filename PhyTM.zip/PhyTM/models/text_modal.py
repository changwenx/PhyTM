"""
Physics-Informed Dual-Stream Attention for Textual Time Series
==============================================================
Implements the textual path of PhyTM
(paper §"Physics-Informed Dual-Stream Attention for Textual Time Series").

Two parallel streams are fused inside a physics-informed Transformer encoder:

  Stream 1 (semantic):  channel-wise natural-language prompt
                        -> frozen GPT-2 word-token embedding (wte)
                        -> Linear(768 -> d) projection
  Stream 2 (numerical): patched series -> Linear(patch_len -> d)

A DMD-derived bias B[i, j] is injected directly into the attention logits as a
relative-position bias along the temporal axis:

  B[i, j] = sum_k beta_k * exp(-|alpha_k| * |i-j|) * cos(omega_k * |i-j|)
  Attn_phys = softmax(Q K^T / sqrt(d) + B) V

so the attention weights jointly reflect semantic similarity and physical
dynamical affinity, overcoming the limitations of generic positional encoding.
The encoder output is mean-pooled to yield Z_txt for the tri-path fusion.

Prompt template (paper §"Textual Modality Construction"):
  Dataset: <name> [desc.: <description>]
  Task: [in_len: <seq_len>] [out_len: <pred_len>]
  Sample: [start: <month>/<day>] [span: <hours>h]
  Statistics: [freq: <freq>] [mean: <X>] [std: <X>] [min: <X>] [max: <X>]
"""
import math
import warnings
import torch
import torch.nn as nn
import torch.nn.functional as F

from .verbosity import is_verbose


# ── dataset-level metadata ────────────────────────────────────────
DATASET_INFO = {
    'etth1': dict(desc='electricity transformer temperature', freq='1h'),
    'etth2': dict(desc='electricity transformer temperature', freq='1h'),
    'ettm1': dict(desc='electricity transformer temperature', freq='15min'),
    'ettm2': dict(desc='electricity transformer temperature', freq='15min'),
    'weather': dict(desc='weather station indicators', freq='10min'),
    'electricity': dict(desc='client electricity consumption', freq='1h'),
    'traffic': dict(desc='road traffic occupancy', freq='1h'),
    'exchange_rate': dict(desc='currency exchange rate', freq='1d'),
    'national_illness': dict(desc='influenza-like illness rate', freq='1w'),
}


def build_prompt(dataset: str, seq_len: int, pred_len: int,
                 sample_idx: int, stats: torch.Tensor) -> str:
    """Construct a per-sample, per-channel natural-language prompt from
    dataset metadata and channel statistics.

    Args:
        dataset: dataset name (lower case)
        seq_len/pred_len: lookback / forecast horizon
        sample_idx: index of the sample (used to synthesise month/day context)
        stats: [4] = [mean, std, min, max] for a single channel
    Returns:
        prompt string
    """
    info = DATASET_INFO.get(dataset.lower(),
                            dict(desc=f'{dataset} time series', freq='1h'))
    # derive a virtual date from idx (only to provide temporal context, not exact)
    month = (sample_idx // 720) % 12 + 1     # 720h ~ 1 month
    day   = (sample_idx //  24) % 30 + 1
    mean, std, mn, mx = [float(v) for v in stats[:4]]
    return (
        f"Dataset: {dataset} [desc.: {info['desc']}] "
        f"Task: [in_len: {seq_len}] [out_len: {pred_len}] "
        f"Sample: [start: {month:02d}/{day:02d}] [span: {seq_len}{info['freq'][:1]}] "
        f"Statistics: [freq: {info['freq']}] "
        f"[mean: {mean:+.2f}] [std: {std:.2f}] "
        f"[min: {mn:+.2f}] [max: {mx:+.2f}]"
    )


# ── DMD-derived physical bias matrix ──────────────────────────────
def physics_bias_matrix(alpha: torch.Tensor,
                        omega: torch.Tensor,
                        beta:  torch.Tensor,
                        S:     int) -> torch.Tensor:
    """Build the bias matrix B[i,j] = sum_k beta_k * exp(-|alpha_k|*d) * cos(omega_k*d),
    the lag-domain response of a damped oscillator (d = |i-j|).

    Args:
        alpha: [B, K]
        omega: [B, K]
        beta:  [K]
        S:     sequence length (number of patch tokens)
    Returns:
        [B, S, S]
    """
    device = alpha.device
    idx  = torch.arange(S, device=device)
    dist = (idx[:, None] - idx[None, :]).abs().to(alpha.dtype)
    dist = dist[None, None, :, :]
    a_abs = alpha.abs().unsqueeze(-1).unsqueeze(-1)
    om    = omega.unsqueeze(-1).unsqueeze(-1)
    b_w   = beta.view(1, -1, 1, 1)
    return (b_w * torch.exp(-a_abs * dist) * torch.cos(om * dist)).sum(dim=1)


# ── physics-biased self-attention ─────────────────────────────────
class PhysicsBiasedSelfAttention(nn.Module):
    def __init__(self, d_model, n_heads=8):
        super().__init__()
        assert d_model % n_heads == 0
        self.n_heads = n_heads
        self.d_head  = d_model // n_heads
        self.qkv     = nn.Linear(d_model, 3 * d_model, bias=False)
        self.out_proj= nn.Linear(d_model, d_model, bias=False)

    def forward(self, x, phys_bias):
        B, S, D = x.shape
        qkv = self.qkv(x).reshape(B, S, 3, self.n_heads, self.d_head)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        scores = q @ k.transpose(-2, -1) / math.sqrt(self.d_head)
        scores = scores + phys_bias.unsqueeze(1)        # add bias to every head
        out = (F.softmax(scores, dim=-1) @ v).transpose(1, 2).reshape(B, S, D)
        return self.out_proj(out)


class FFN(nn.Module):
    def __init__(self, d_model, d_ff=None):
        super().__init__()
        d_ff = d_ff or 4 * d_model
        self.fc1, self.fc2, self.act = (
            nn.Linear(d_model, d_ff), nn.Linear(d_ff, d_model), nn.GELU())
    def forward(self, x):
        return self.fc2(self.act(self.fc1(x)))


class PhysicsBiasedLayer(nn.Module):
    def __init__(self, d_model, n_heads=8):
        super().__init__()
        self.attn = PhysicsBiasedSelfAttention(d_model, n_heads)
        self.ffn  = FFN(d_model)
        self.ln1  = nn.LayerNorm(d_model)
        self.ln2  = nn.LayerNorm(d_model)
    def forward(self, x, phys_bias):
        x = self.ln1(x + self.attn(x, phys_bias))
        return self.ln2(x + self.ffn(x))


# ── dual-stream textual modal encoder ─────────────────────────────
class TextModalEncoder(nn.Module):
    """Dual-stream physics-biased Transformer.

    Stream 1: prompt -> frozen GPT-2 wte -> Linear(768 -> d)
    Stream 2: patched series -> Linear(patch_len -> d)
    concat -> physics-biased Transformer x n_layers
    """
    def __init__(
        self,
        seq_len:        int,
        patch_len:      int   = 16,
        d_model:        int   = 128,
        n_layers:       int   = 3,
        n_heads:        int   = 8,
        n_modes:        int   = 8,
        gpt2_path:      str   = '/home/zc/cwx/model/gpt2/',
        max_prompt_len: int   = 80,
        # dataset metadata (used to build prompts in forward)
        dataset:        str   = 'etth1',
        pred_len:       int   = 96,
        # enable/disable the GPT-2 semantic stream (ablation)
        use_gpt2:       bool  = True,
    ):
        super().__init__()
        assert seq_len % patch_len == 0
        self.seq_len        = seq_len
        self.pred_len       = pred_len
        self.dataset        = dataset
        self.n_patches      = seq_len // patch_len
        self.patch_len      = patch_len
        self.d_model        = d_model
        self.use_gpt2       = use_gpt2
        self.max_prompt_len = max_prompt_len

        # patch embedding (stream 2)
        self.patch_embed = nn.Linear(patch_len, d_model)

        # GPT-2 word-token embedding + projection (stream 1)
        if use_gpt2:
            from transformers import GPT2Tokenizer, GPT2Model
            try:
                from transformers.utils import logging as hf_logging
                hf_logging.set_verbosity_error()
            except Exception:
                pass
            # Load the frozen GPT-2 word embedding without any console noise.
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                self.tokenizer = GPT2Tokenizer.from_pretrained(gpt2_path)
                self.tokenizer.pad_token = self.tokenizer.eos_token
                gpt2 = GPT2Model.from_pretrained(gpt2_path)
            self.wte = gpt2.wte                       # [vocab, 768]
            del gpt2
            for p in self.wte.parameters():
                p.requires_grad = False               # frozen
            self.text_proj = nn.Linear(768, d_model, bias=False)
            # zero-init: text_proj outputs 0 initially so the semantic stream
            # contributes no random gradient noise to the physical parameters;
            # text_gate gradually opens the stream during training.
            nn.init.zeros_(self.text_proj.weight)
            if is_verbose():
                print("[Text] dual-stream: frozen GPT-2 wte + patch embedding")
        else:
            self.wte       = None
            self.text_proj = None
            if is_verbose():
                print("[Text] single-stream: patch embedding only (GPT-2 disabled)")

        # positional encoding over the patch sequence
        self.pos = nn.Parameter(torch.zeros(1, self.n_patches, d_model))
        nn.init.trunc_normal_(self.pos, std=0.02)

        # gate for injecting the semantic stream; zero-init so the prompt
        # stream stays inert early on and opens up adaptively during training.
        if use_gpt2:
            self.text_gate = nn.Parameter(torch.zeros(1))

        # physical-bias parameters
        self.beta            = nn.Parameter(torch.full((n_modes,), 1.0 / n_modes))
        self._bias_scale_raw = nn.Parameter(torch.zeros(1))

        # ablation switch: when use_phys=False the DMD bias is not injected and
        # PhysicsBiasedSelfAttention degenerates to standard multi-head attention.
        self.use_phys = True

        # physics-biased Transformer layers
        self.layers = nn.ModuleList([
            PhysicsBiasedLayer(d_model, n_heads) for _ in range(n_layers)
        ])

    @property
    def bias_scale(self):
        return F.softplus(self._bias_scale_raw)

    def _build_prompts(self, B_total: int, C: int, sample_idx: torch.Tensor,
                       stats: torch.Tensor) -> torch.Tensor:
        """Build one prompt per (sample, channel) and encode to [B*C, L_text, d].

        Args:
            B_total: B * C
            C: number of channels (used to unpack sample_idx)
            sample_idx: [B] index of each batch sample
            stats: [B, 4, C] mean/std/min/max per channel
        Returns:
            [B*C, L_text, d] text embedding
        """
        device = sample_idx.device
        B      = sample_idx.shape[0]

        prompts = []
        for b in range(B):
            idx_b = int(sample_idx[b].item())
            for c in range(C):
                s = stats[b, :, c]   # [4]
                prompts.append(build_prompt(
                    self.dataset, self.seq_len, self.pred_len, idx_b, s))

        # tokenise the batch (pad to a common length)
        enc = self.tokenizer(
            prompts, padding='max_length', truncation=True,
            max_length=self.max_prompt_len, return_tensors='pt')
        ids = enc['input_ids'].to(device)        # [B*C, L_text]

        # wte lookup + linear projection
        emb = self.wte(ids)                       # [B*C, L_text, 768]
        emb = self.text_proj(emb)                 # [B*C, L_text, d]
        return emb

    def forward(self, x: torch.Tensor,
                alpha: torch.Tensor, omega: torch.Tensor,
                sample_idx: torch.Tensor = None,
                stats: torch.Tensor = None,
                C: int = 1) -> torch.Tensor:
        """
        Args:
            x: [B*C, T]   channel-independent normalised series
            alpha/omega: [B*C, K] DMD physical spectrum
            sample_idx: [B]  sample index (to build prompts)
            stats: [B, 4, C] mean/std/min/max of the current window
            C: number of channels
        Returns:
            [B*C, S, d]   patch tokens with the semantic stream injected as global context
        """
        BC, T = x.shape
        S, L  = self.n_patches, self.patch_len

        # stream 2 (primary): patch embed + positional encoding
        Z = self.patch_embed(x.reshape(BC, S, L)) + self.pos      # [B*C, S, d]

        # stream 1 (auxiliary): prompt -> GPT-2 wte -> projection -> global pool
        # -> injected into every patch via the zero-init text_gate
        if self.use_gpt2 and sample_idx is not None and stats is not None:
            B = sample_idx.shape[0]
            assert BC == B * C, f"dim mismatch BC={BC} B*C={B}*{C}={B*C}"
            Z_text = self._build_prompts(BC, C, sample_idx, stats)  # [B*C, L_text, d]
            text_global = Z_text.mean(dim=1, keepdim=True)          # [B*C, 1, d]
            Z = Z + torch.tanh(self.text_gate) * text_global        # broadcast

        # DMD-derived physical bias over the S patch tokens
        if self.use_phys:
            phys_bias = physics_bias_matrix(alpha, omega, self.beta, S) * self.bias_scale
        else:
            # ablation (no Phys-Transformer): zero bias -> standard self-attention
            phys_bias = Z.new_zeros(BC, S, S)

        # physics-biased Transformer
        for layer in self.layers:
            Z = layer(Z, phys_bias)
        return Z
