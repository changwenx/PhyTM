"""
Numerical Path (paper §"Numerical Path")
========================================
Processes the raw historical observations directly, preserving temporal
fidelity without any modality conversion. A hybrid encoder combines a
linear-time MLP-Mixer backbone with a lightweight selective-scan Mamba layer
(long-range sequence modelling) and a lightweight Transformer layer (global
patch attention), followed by attention pooling to yield Z_num.

    patch embed [B*C, P, d]
    -> MLP-Mixer x n_gtm_layers   (linear-time token mixing)
    -> Light Mamba x 1            (selective state scan)
    -> Light Transformer x 1      (global attention)
    -> attention pool -> [B, C, d]

The two auxiliary modules use gamma-scaled residuals (init 0.1) so they refine
rather than override the Mixer backbone; the Mamba layer falls back to a pure
PyTorch scan when mamba-ssm is unavailable.
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from mamba_ssm.ops.selective_scan_interface import selective_scan_fn
    MAMBA_AVAILABLE = True
except ImportError:
    MAMBA_AVAILABLE = False


# ── backbone: MLP-Mixer ───────────────────────────────────────────
class MLPMixer(nn.Module):
    """Token (inter-patch) mixing."""
    def __init__(self, n_patches: int, d_model: int, dropout: float = 0.1):
        super().__init__()
        self.norm     = nn.LayerNorm(d_model)
        self.time_mix = nn.Linear(n_patches, n_patches)
        self.act      = nn.GELU()
        self.drop     = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.norm(x).transpose(1, 2)
        h = self.drop(self.act(self.time_mix(h)))
        return x + h.transpose(1, 2)


# ── lightweight unidirectional Mamba ──────────────────────────────
class LightMamba(nn.Module):
    """expand=1, d_state=16 lightweight unidirectional Mamba.
    gamma-scaled residual (init 0.1) so it does not overwhelm the Mixer backbone.
    """
    def __init__(self, d_model: int, d_state: int = 16,
                 d_conv: int = 4, dropout: float = 0.1):
        super().__init__()
        d = d_model
        self.in_proj  = nn.Linear(d, d * 2, bias=False)
        self.conv1d   = nn.Conv1d(d, d, d_conv,
                                  padding=d_conv - 1, groups=d)
        self.x_proj   = nn.Linear(d, d_state * 2 + 1, bias=False)
        self.dt_proj  = nn.Linear(1, d, bias=True)
        nn.init.uniform_(self.dt_proj.bias,
                         math.log(1e-3), math.log(1e-1))
        self.A_log    = nn.Parameter(torch.log(
            torch.arange(1, d_state + 1, dtype=torch.float32)
            .unsqueeze(0).expand(d, -1)))
        self.D        = nn.Parameter(torch.ones(d))
        self.out_proj = nn.Linear(d, d, bias=False)
        self.norm     = nn.LayerNorm(d)
        self.drop     = nn.Dropout(dropout)
        # gamma-scaled residual: init 0.1, grows adaptively during training
        self.gamma    = nn.Parameter(torch.ones(1) * 0.1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: [B, L, d] -> [B, L, d]"""
        B, L, D = x.shape
        xn  = self.norm(x)
        xz  = self.in_proj(xn)
        xs, z = xz.chunk(2, dim=-1)
        xc  = self.conv1d(xs.permute(0, 2, 1))[:, :, :L].permute(0, 2, 1)
        xc  = F.silu(xc)

        d_state = self.A_log.shape[1]
        xd  = self.x_proj(xc)
        dt, B_s, C_s = xd.split([1, d_state, d_state], dim=-1)
        dt  = F.softplus(self.dt_proj(dt))
        A   = -torch.exp(self.A_log.float())

        u_t  = xc.permute(0, 2, 1).float()
        dt_t = dt.permute(0, 2, 1).float()
        B_t  = B_s.permute(0, 2, 1).float()
        C_t  = C_s.permute(0, 2, 1).float()

        if MAMBA_AVAILABLE:
            y = selective_scan_fn(u_t, dt_t, A, B_t, C_t,
                                  self.D.float(), delta_softplus=False)
        else:
            # pure PyTorch fallback (slower but correct)
            dA  = torch.exp(dt_t.unsqueeze(-1) * A.unsqueeze(0).unsqueeze(2))
            dBu = dt_t * u_t
            h   = torch.zeros(B, D, d_state,
                              device=x.device, dtype=torch.float32)
            ys  = []
            for t in range(L):
                h = dA[:, :, t] * h + \
                    dBu[:, :, t].unsqueeze(-1) * B_t[:, :, t].unsqueeze(1)
                ys.append((h * C_t[:, :, t].unsqueeze(1)).sum(-1))
            y = torch.stack(ys, dim=2)

        y   = (y + self.D.unsqueeze(-1) * u_t).permute(0, 2, 1).to(x.dtype)
        out = self.drop(self.out_proj(y * F.silu(z)))
        return x + self.gamma * out


# ── lightweight Transformer block ─────────────────────────────────
class LightTransformer(nn.Module):
    """Pre-LN block with a 1x FFN expansion (not 4x) to stay lightweight.
    gamma-scaled residuals, init 0.1.
    """
    def __init__(self, d_model: int, n_heads: int = 4,
                 dropout: float = 0.1):
        super().__init__()
        # ensure d_model is divisible by n_heads
        while d_model % n_heads != 0:
            n_heads = n_heads // 2
        self.ln1  = nn.LayerNorm(d_model)
        self.ln2  = nn.LayerNorm(d_model)
        self.attn = nn.MultiheadAttention(
            d_model, n_heads, dropout=dropout, batch_first=True)
        self.ff1  = nn.Linear(d_model, d_model)  # 1x not 4x
        self.ff2  = nn.Linear(d_model, d_model)
        self.act  = nn.GELU()
        self.drop = nn.Dropout(dropout)
        self.gamma1 = nn.Parameter(torch.ones(1) * 0.1)
        self.gamma2 = nn.Parameter(torch.ones(1) * 0.1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.ln1(x)
        h, _ = self.attn(h, h, h, need_weights=False)
        x = x + self.gamma1 * self.drop(h)
        h = self.ln2(x)
        return x + self.gamma2 * self.drop(self.ff2(self.act(self.ff1(h))))


# ── attention pooling ─────────────────────────────────────────────
class AttentionPool(nn.Module):
    def __init__(self, d_model: int):
        super().__init__()
        self.query = nn.Parameter(torch.zeros(1, 1, d_model))
        nn.init.trunc_normal_(self.query, std=0.02)
        self.attn = nn.MultiheadAttention(
            d_model, num_heads=min(4, d_model // 16), batch_first=True)
        self.norm = nn.LayerNorm(d_model)

    def forward(self, h: torch.Tensor) -> torch.Tensor:
        BC = h.size(0)
        q = self.query.expand(BC, -1, -1)
        out, _ = self.attn(q, h, h, need_weights=False)
        return self.norm(out.squeeze(1))


# ── numerical path ────────────────────────────────────────────────
class NumericalPath(nn.Module):
    """MLP-Mixer backbone + lightweight Mamba + lightweight Transformer.

    input:  x_norm [B, T, C]
    output: [B, C, d_model]
    """
    def __init__(
        self,
        seq_len:        int,
        n_vars:         int   = 1,
        patch_len:      int   = 16,
        patch_stride:   int   = 8,
        d_model:        int   = 128,
        n_gtm_layers:   int   = 2,
        dropout:        float = 0.1,
        d_state:        int   = 16,
        n_cross_layers: int   = 1,
        n_heads:        int   = 8,
    ):
        super().__init__()
        self.patch_len    = patch_len
        self.patch_stride = patch_stride
        self.d_model      = d_model
        self.n_patches    = (seq_len - patch_len) // patch_stride + 1
        P = self.n_patches

        # patch embedding
        self.patch_proj = nn.Linear(patch_len, d_model)
        self.pos_embed  = nn.Parameter(torch.zeros(1, 1, P, d_model))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

        # MLP-Mixer backbone
        self.mixer_layers = nn.ModuleList([
            MLPMixer(P, d_model, dropout)
            for _ in range(max(1, n_gtm_layers))
        ])

        # lightweight Mamba (1 layer, gamma=0.1 residual)
        self.mamba = LightMamba(d_model, d_state=d_state, dropout=dropout)

        # lightweight Transformer (1 layer, gamma=0.1 residual)
        self.transformer = LightTransformer(
            d_model, n_heads=min(4, n_heads), dropout=dropout)

        # attention pooling
        self.pool     = AttentionPool(d_model)
        self.dropout  = nn.Dropout(dropout)
        self.out_norm = nn.LayerNorm(d_model)

    def forward(self, x_norm: torch.Tensor, E=None) -> torch.Tensor:
        B, T, C = x_norm.shape

        # patch embedding
        x_t = x_norm.permute(0, 2, 1)
        x_p = x_t.unfold(-1, self.patch_len, self.patch_stride)   # [B, C, P, L]
        h   = self.patch_proj(x_p) + self.pos_embed               # [B, C, P, d]
        h   = self.dropout(h)
        h   = h.reshape(B * C, self.n_patches, self.d_model)      # [B*C, P, d]

        # MLP-Mixer backbone
        for layer in self.mixer_layers:
            h = layer(h)

        # Mamba (selective state scan, gamma-scaled residual)
        h = self.mamba(h)

        # Transformer (global attention, gamma-scaled residual)
        h = self.transformer(h)

        h = self.out_norm(h)

        # attention pool -> [B*C, d] -> [B, C, d]
        h = self.pool(h)
        return h.reshape(B, C, self.d_model)
