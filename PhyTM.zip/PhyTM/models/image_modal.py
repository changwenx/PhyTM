"""
Physics-Structured State-Space Mamba for Imagified Time Series
==============================================================
Implements the visual path of PhyTM
(paper §"Physics-Structured State-Space Mamba for Imagified Time Series").

The time series is transformed into a Gramian Angular Field (GAF) and encoded
by a Mamba whose state-transition matrix is constructed directly from the
DMD-extracted spectrum. Each dynamical mode k is a 2x2 rotation-decay block

    A_k = [[alpha_k, -omega_k], [omega_k, alpha_k]],   eigenvalues alpha_k +- i*omega_k

assembled block-diagonally so the eigenstructure matches the DMD spectrum.
Zero-order-hold discretisation gives, per mode,

    Abar_k = e^{alpha_k*dt} * [[cos(omega_k dt), -sin(omega_k dt)],
                               [sin(omega_k dt),  cos(omega_k dt)]],

and since alpha_k < 0 the spectral radius e^{alpha_k dt} < 1 guarantees
long-horizon stability that unconstrained SSMs cannot offer.

Efficient kernel mapping
------------------------
``selective_scan_fn`` requires a real diagonal A [D, N]. The rotation-decay
block is therefore split into a pure-decay part (alpha_k -> A_log, handled by
the parallel scan) and a rotation part (omega_k -> time-varying modulation of
B_t / C_t). With dt the decay and rotation are absorbed into the discretised
state update, keeping linear-time efficiency. When mamba-ssm is unavailable a
zero-Python-loop cumsum-based parallel scan is used as a fallback.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from .verbosity import is_verbose

try:
    from mamba_ssm.ops.selective_scan_interface import selective_scan_fn
    MAMBA_AVAILABLE = True
except ImportError:
    MAMBA_AVAILABLE = False


# ─────────────────── GAF ───────────────────
def compute_gaf(x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    """Gramian Angular Field. x: [B, T] -> [B, T, T] in [-1, 1].
    G[i, j] = cos(phi_i + phi_j) with phi_t = arccos(normalised x_t)."""
    x_min = x.min(dim=1, keepdim=True).values
    x_max = x.max(dim=1, keepdim=True).values
    x_n   = (2 * x - x_max - x_min) / (x_max - x_min + eps)
    x_n   = x_n.clamp(-1.0 + eps, 1.0 - eps)
    phi   = torch.arccos(x_n)
    return torch.cos(phi[:, :, None] + phi[:, None, :])


# ─────────────────── Physics-Structured SSM ───────────────────
class PhysicsStructuredSSM(nn.Module):
    """Physics-structured state-space block, using selective_scan_fn when available.

    The 2x2 rotation-decay block A_k is decoupled into:
        - decay part alpha_k -> A_log (fed to the parallel scan)
        - rotation part omega_k -> time-varying modulation of B_t / C_t

    so the scan sees a purely real diagonal system (its interface requirement)
    while the rotation semantics are preserved through the time-varying B_t, C_t.

    Equivalence:
        h(t) = Abar_k h(t-1) + Bbar_k u_t        (Abar_k damped-rotation)
        complex form  h_c(t) = e^{(alpha+i omega) dt} h_c(t-1) + b_c u_t
        real scan  y_c(t) = C_c * h_c(t)
                          = C_c * [e^{alpha dt} h_c(t-1) + b_c u_t]
        -> A = e^{alpha dt} (real decay) + rotation modulation on B_t / C_t
    """

    def __init__(
        self,
        d_model:    int,
        n_modes:    int,
        d_conv:     int   = 4,
        dt_min:     float = 1e-3,
        dt_max:     float = 1.0,
        alpha_clip: float = 5.0,
    ):
        super().__init__()
        self.d_model  = d_model
        self.K        = n_modes
        self.two_k    = 2 * n_modes   # real + imaginary channels = 2K state dims
        self.dt_min   = dt_min
        self.dt_max   = dt_max
        self.alpha_clip = alpha_clip

        self.in_norm   = nn.LayerNorm(d_model)
        self.conv1d    = nn.Conv1d(d_model, d_model, kernel_size=d_conv,
                                   groups=d_model, padding=d_conv - 1)
        self.act       = nn.SiLU()
        self.gate_proj = nn.Linear(d_model, d_model, bias=False)

        # selective_scan parameters; d_inner = 2K (K real + K imaginary channels)
        self.d_inner = self.two_k

        self.in_proj  = nn.Linear(d_model, self.d_inner, bias=False)
        self.dt_proj  = nn.Linear(d_model, self.d_inner, bias=True)
        nn.init.constant_(self.dt_proj.bias,
                          torch.log(torch.tensor(dt_min)).item())  # small initial step
        self.B_proj   = nn.Linear(d_model, self.d_inner, bias=False)
        self.C_proj   = nn.Linear(d_model, self.d_inner, bias=False)
        self.D        = nn.Parameter(torch.ones(self.d_inner))
        self.out_proj = nn.Linear(self.d_inner, d_model, bias=False)

    def forward(self,
                x:     torch.Tensor,
                alpha: torch.Tensor,
                omega: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x:     [B, S, D]
            alpha: [B, K]   DMD decay spectrum (with learnable residual)
            omega: [B, K]   DMD frequency spectrum
        Returns:
            [B, S, D]
        """
        B, S, D = x.shape
        K = self.K

        x_n  = self.in_norm(x)
        gate = self.act(self.gate_proj(x_n))          # [B, S, D]

        # local convolution
        u = self.conv1d(x_n.transpose(1, 2))[:, :, :S].transpose(1, 2)
        u = self.act(u)                                # [B, S, D]

        # step size dt: [B, S, 2K], softplus + clamp
        dt = F.softplus(self.dt_proj(u))               # [B, S, 2K]
        dt = dt.clamp(self.dt_min, self.dt_max)

        # ── time-varying B_t / C_t with rotation modulation ───────
        B_raw = self.B_proj(u)                         # [B, S, 2K]
        C_raw = self.C_proj(u)                         # [B, S, 2K]

        # rotation modulation factors cos(omega dt) / sin(omega dt)
        a_exp = alpha.unsqueeze(1).expand(B, S, K)     # [B, S, K]
        w_exp = omega.unsqueeze(1).expand(B, S, K)     # [B, S, K]
        dt_k  = dt[:, :, :K]                           # [B, S, K]

        ang   = w_exp * dt_k                           # omega * dt
        cos_a = torch.cos(ang)
        sin_a = torch.sin(ang)

        # real channel  B_re = B_re*cos - B_im*sin
        # imag channel  B_im = B_re*sin + B_im*cos
        B_re_raw = B_raw[:, :, :K]
        B_im_raw = B_raw[:, :, K:]
        B_re = B_re_raw * cos_a - B_im_raw * sin_a
        B_im = B_re_raw * sin_a + B_im_raw * cos_a
        B_mod = torch.cat([B_re, B_im], dim=-1)        # [B, S, 2K]

        C_re_raw = C_raw[:, :, :K]
        C_im_raw = C_raw[:, :, K:]
        C_re = C_re_raw * cos_a - C_im_raw * sin_a
        C_im = C_re_raw * sin_a + C_im_raw * cos_a
        C_mod = torch.cat([C_re, C_im], dim=-1)        # [B, S, 2K]

        # ── A (pure decay; rotation already in B/C) ───────────────
        # selective_scan_fn uses a global A [D, N]; per-sample alpha is handled
        # with the standard delta-rescaling trick:
        #   e^{alpha_k dt} = e^{alpha_bar_k dt} * e^{(alpha_k-alpha_bar_k) dt}
        # the residual factor is folded into B_t.
        alpha_mean = alpha.mean(dim=0)                 # [K] batch-mean decay
        alpha_mean = alpha_mean.clamp(-self.alpha_clip, 0.0)  # enforce stability (<=0)
        A_log = torch.cat([alpha_mean, alpha_mean], dim=0).unsqueeze(-1)  # [2K, 1]
        A = A_log                                      # [2K, 1]

        # compensation factor for the per-sample deviation from the batch mean
        alpha_diff = alpha - alpha_mean.unsqueeze(0)   # [B, K]
        comp = torch.exp(alpha_diff.unsqueeze(1) * dt_k)   # [B, S, K]
        comp = torch.cat([comp, comp], dim=-1)         # [B, S, 2K]
        B_mod = B_mod * comp

        # ── selective_scan_fn ─────────────────────────────────────
        u_scan     = self.in_proj(u).transpose(1, 2)   # [B, 2K, S]
        delta_scan = dt.transpose(1, 2)                # [B, 2K, S]
        B_scan     = B_mod.permute(0, 2, 1)            # [B, 2K, S]
        C_scan     = C_mod.permute(0, 2, 1)            # [B, 2K, S]

        if MAMBA_AVAILABLE:
            # per-channel independent B/C: [B, 2K, 1, S]
            B_ss = B_scan.unsqueeze(2)
            C_ss = C_scan.unsqueeze(2)
            y = selective_scan_fn(
                u_scan,                                # [B, 2K, S]
                delta_scan,                            # [B, 2K, S]
                A,                                     # [2K, 1]
                B_ss,                                  # [B, 2K, 1, S]
                C_ss,                                  # [B, 2K, 1, S]
                self.D,                                # [2K]
                delta_softplus=False,                  # softplus already applied
            )                                          # [B, 2K, S]
        else:
            y = self._parallel_scan_fallback(
                u_scan, delta_scan, A, B_scan, C_scan
            )                                          # [B, 2K, S]

        y = y.transpose(1, 2)                          # [B, S, 2K]
        y = self.out_proj(y)                           # [B, S, D]
        y = y * gate
        return y

    def _parallel_scan_fallback(self, u, delta, A, B, C):
        """Efficient fallback when mamba-ssm is unavailable: cumsum-based
        parallel scan, no Python loop.

        Per channel (d_state=1):
            h(t) = a(t) * h(t-1) + b(t) * u(t),  a(t) = exp(delta(t) * A)
            y(t) = c(t) * h(t)
        """
        B_b, D, S = u.shape
        a = torch.exp(delta * A.squeeze(-1).unsqueeze(0).unsqueeze(-1))  # [B, D, S]
        bu = B * u                                    # [B, D, S]

        # log-domain prefix product: h(t) = a_cum[t] * sum_{s<=t} bu(s) / a_cum[s]
        log_a  = torch.log(a.clamp(min=1e-8))         # [B, D, S]
        log_a_cum = log_a.cumsum(dim=-1)              # [B, D, S]
        a_cum   = torch.exp(log_a_cum)
        inv_a   = torch.exp(-log_a_cum)
        h_unnorm = (bu * inv_a).cumsum(dim=-1)
        h       = a_cum * h_unnorm

        y = C * h + self.D.unsqueeze(0).unsqueeze(-1) * u
        return y


# ─────────────────── image modal encoder ───────────────────
class ImageModalEncoder(nn.Module):
    """GAF tokenisation + physics-structured SSM.

    The series is downsampled to S points, a small S x S GAF is computed, and
    each row is reduced by its mean to a length-S feature sequence (preserving
    the global angular-correlation structure at O(S) cost). The sequence is then
    processed by stacked physics-structured SSM blocks.
    """
    def __init__(
        self,
        seq_len:    int,
        patch_len:  int = 16,
        d_model:    int = 256,
        n_layers:   int = 2,
        n_modes:    int = 8,
        img_size:   int = None,  # kept for signature compatibility, unused
        img_patch:  int = None,  # ditto
    ):
        super().__init__()
        assert seq_len % patch_len == 0, \
            f"seq_len={seq_len} must be divisible by patch_len={patch_len}"

        self.T          = seq_len
        self.patch_len  = patch_len
        self.n_patches  = seq_len // patch_len   # S = T / patch_len
        self.d_model    = d_model
        self.K          = n_modes

        # ablation switch: when use_phys=False the DMD spectrum (alpha, omega) is
        # replaced by the learnable parameters below, so the block degenerates to
        # a standard Mamba (learnable dynamics, no physical prior). The SSM forward
        # is unchanged; only the source of (alpha, omega) differs (same shapes).
        self.use_phys   = True
        self.alpha_std  = nn.Parameter(torch.full((n_modes,), -0.5))  # learnable decay
        self.omega_std  = nn.Parameter(torch.zeros(n_modes))          # learnable frequency

        # after downsampling each patch is a scalar -> Linear(1, d_model)
        self.patch_embed = nn.Linear(1, d_model)
        self.pos_embed   = nn.Parameter(torch.zeros(1, self.n_patches, d_model))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

        self.layers = nn.ModuleList([
            PhysicsStructuredSSM(d_model, n_modes=n_modes) for _ in range(n_layers)
        ])
        self.norms = nn.ModuleList([nn.LayerNorm(d_model) for _ in range(n_layers)])

        if not MAMBA_AVAILABLE and is_verbose():
            print("[Image] mamba-ssm not found, using parallel-scan fallback")

    def forward(self, x, alpha, omega):
        """
        x:     [B, T]
        alpha: [B, K]
        omega: [B, K]
        -> [B, S, D]
        """
        B, T = x.shape

        # downsample to S points before the GAF to keep the GAF small (S x S)
        S, L = self.n_patches, self.patch_len
        x_ds = F.adaptive_avg_pool1d(x.unsqueeze(1), S).squeeze(1)   # [B, S]
        gaf_small = compute_gaf(x_ds)                                # [B, S, S]
        gaf_feat = gaf_small.mean(dim=-1)                            # [B, S]
        z = self.patch_embed(gaf_feat.unsqueeze(-1))                 # [B, S, D]
        z = z + self.pos_embed

        # ablation (no Phys-Mamba): use learnable spectrum -> standard Mamba
        if not self.use_phys:
            alpha = self.alpha_std.unsqueeze(0).expand(B, self.K)
            omega = self.omega_std.unsqueeze(0).expand(B, self.K)

        for layer, norm in zip(self.layers, self.norms):
            z = norm(z + layer(z, alpha, omega))
        return z
