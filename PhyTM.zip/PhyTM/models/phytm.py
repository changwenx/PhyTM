"""
PhyTM: Physics-Informed Tri-Modal Forecasting Model
===================================================
The tri-path architecture of PhyTM
(paper §"Physics-Informed Tri-Path Feature Fusion" and §"Tri-Path Feature Fusion").

    DMD physics extractor  ->  refined spectrum (alpha_tilde, omega_tilde)
        |
        |-> textual path    : physics-informed dual-stream attention Transformer
        |-> visual path     : GAF + physics-structured state-space Mamba
        |-> numerical path  : hybrid Transformer-Mamba (raw temporal fidelity)

The three paths produce representations of a unified dimension d_fused. They are
combined by independent sigmoid gates (and an optional cross-variable attention
for high-dimensional datasets) and mapped to the forecast horizon by a two-layer
MLP head. The output is inverse-normalised (RevIN) to the original scale.

The physics regulariser L_phys = ||Delta alpha||^2 + ||Delta omega||^2 is exposed
via self.physics_regularization().
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from .physics_extractor import DMDPhysicsExtractor
from .text_modal        import TextModalEncoder
from .image_modal       import ImageModalEncoder
from .numerical_path    import NumericalPath


class PhyTM(nn.Module):
    # path switches (toggled by the ablation configuration)
    enable_text  = True
    enable_image = True
    enable_num   = True

    def __init__(
        self,
        seq_len:        int,
        pred_len:       int,
        n_vars:         int   = 1,
        patch_len:      int   = 16,
        patch_stride:   int   = 8,
        img_patch:      int   = 16,
        img_size:       int   = None,
        d_model:        int   = 128,
        d_fused:        int   = 128,
        n_text_layers:  int   = 3,
        n_image_layers: int   = 2,
        n_cross_layers: int   = 2,
        n_gtm_layers:   int   = 3,
        d_state:        int   = 16,
        n_heads:        int   = 8,
        # ── DMD physics extraction ────────────────────────────────
        n_modes:        int   = 8,
        dmd_embed_len:  int   = 8,
        dmd_rank:       int   = None,
        dmd_delta_t:    float = 1.0,
        dropout:        float = 0.1,
        gpt2_path:      str   = '/home/zc/cwx/model/gpt2/',
        max_prompt_len: int   = 80,
        use_gpt2:       bool  = True,
        dataset:        str   = 'etth1',
    ):
        super().__init__()
        self.seq_len  = seq_len
        self.pred_len = pred_len
        self.n_vars   = n_vars
        self.K        = n_modes

        # ── DMD physical-spectrum extractor (with learnable Delta alpha, Delta omega)
        self.phy_extractor = DMDPhysicsExtractor(
            n_modes=n_modes,
            embed_len=dmd_embed_len,
            rank=dmd_rank,
            delta_t=dmd_delta_t,
            learnable=True,
        )

        # ── textual path: physics-informed dual-stream attention Transformer
        self.text_encoder = TextModalEncoder(
            seq_len=seq_len, patch_len=patch_len, d_model=d_model,
            n_layers=n_text_layers, n_heads=n_heads, n_modes=n_modes,
            gpt2_path=gpt2_path, max_prompt_len=max_prompt_len,
            dataset=dataset, pred_len=pred_len, use_gpt2=use_gpt2,
        )

        # ── visual path: GAF + physics-structured state-space Mamba
        self.image_encoder = ImageModalEncoder(
            seq_len=seq_len, patch_len=patch_len,
            d_model=d_model,
            n_layers=n_image_layers, n_modes=n_modes,
        )

        # ── numerical path ────────────────────────────────────────
        self.num_path = NumericalPath(
            seq_len=seq_len, n_vars=n_vars,
            patch_len=patch_len, patch_stride=patch_stride,
            d_model=d_model, d_state=d_state,
            n_cross_layers=n_cross_layers, n_gtm_layers=n_gtm_layers,
            n_heads=n_heads, dropout=dropout,
        )

        # ── per-path projection to the shared dimension d_fused ────
        # token-dim mean-pool then project (avoids a large compression ratio)
        self.proj_text  = nn.Linear(d_model, d_fused)
        self.proj_image = nn.Linear(d_model, d_fused)
        self.proj_num   = nn.Linear(d_model, d_fused)

        # ── independent sigmoid gates ─────────────────────────────
        self.gate_text  = nn.Linear(d_fused, d_fused, bias=True)
        self.gate_image = nn.Linear(d_fused, d_fused, bias=True)
        self.gate_num   = nn.Linear(d_fused, d_fused, bias=True)
        for g in (self.gate_text, self.gate_image, self.gate_num):
            nn.init.zeros_(g.weight)
            nn.init.zeros_(g.bias)

        # ── cross-variable attention (for high-dimensional datasets) ──
        # C<=15: not created (zero parameters); C>15: global attention so the
        # variables can attend to each other in a data-driven way. cv_gate is
        # zero-init so the module is inert early (tanh(0)=0) and grows during
        # training, without polluting the patch / physics-bias backbone.
        self.use_cv_attn = (n_vars > 15)
        if self.use_cv_attn:
            self.cv_attn = nn.MultiheadAttention(
                d_fused, num_heads=min(4, d_fused // 16),
                batch_first=True, dropout=dropout)
            self.cv_norm = nn.LayerNorm(d_fused)
            self.cv_gate = nn.Parameter(torch.zeros(1))

        # ── prediction head ───────────────────────────────────────
        self.head = nn.Sequential(
            nn.LayerNorm(d_fused),
            nn.Linear(d_fused, d_fused),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_fused, pred_len),
        )

    # ─────────────────── physics regulariser ───────────────────
    def physics_regularization(self) -> torch.Tensor:
        """L_phys = ||Delta alpha||^2 + ||Delta omega||^2 (training loss term)."""
        return self.phy_extractor.physics_regularization()

    # ─────────────────── forward ───────────────────
    def forward(self, x: torch.Tensor,
                sample_idx: torch.Tensor = None,
                stats: torch.Tensor = None) -> torch.Tensor:
        was_2d = (x.dim() == 2)
        if was_2d:
            x = x.unsqueeze(-1)
        B, T, C = x.shape

        # ── RevIN ──────────────────────────────────────────────────
        mu  = x.mean(dim=1, keepdim=True)
        sig = x.std(dim=1, keepdim=True) + 1e-6
        x_n = (x - mu) / sig
        x_ci = x_n.permute(0, 2, 1).reshape(B * C, T)

        # ── DMD physical spectrum (precomputed; zero SVD during training) ──
        if self.enable_text or self.enable_image:
            alpha, omega = self.phy_extractor(B, C, x.device, x.dtype)
        else:
            alpha = omega = None

        # ── textual path ───────────────────────────────────────────
        if self.enable_text:
            z_text = self.proj_text(self.text_encoder(
                x_ci, alpha, omega,
                sample_idx=sample_idx, stats=stats, C=C).mean(dim=1))
        else:
            z_text = x_ci.new_zeros(B * C, self.proj_text.out_features)

        # ── visual path ────────────────────────────────────────────
        if self.enable_image:
            z_image = self.proj_image(self.image_encoder(x_ci, alpha, omega).mean(dim=1))
        else:
            z_image = x_ci.new_zeros(B * C, self.proj_image.out_features)

        # ── numerical path ─────────────────────────────────────────
        if self.enable_num:
            z_num = self.proj_num(self.num_path(x_n).reshape(B * C, self.num_path.d_model))
        else:
            z_num = x_ci.new_zeros(B * C, self.proj_num.out_features)

        # ── tri-path gated fusion ──────────────────────────────────
        z = (torch.sigmoid(self.gate_text(z_text))  * z_text
           + torch.sigmoid(self.gate_image(z_image)) * z_image
           + torch.sigmoid(self.gate_num(z_num))    * z_num)

        # ── cross-variable attention (global, for C>15) ───────────
        if self.use_cv_attn and C > 1:
            z_cv = z.reshape(B, C, -1)                          # [B, C, d]
            z_attn, _ = self.cv_attn(z_cv, z_cv, z_cv, need_weights=False)
            z_cv = self.cv_norm(z_cv + torch.tanh(self.cv_gate) * z_attn)
            z = z_cv.reshape(B * C, -1)

        y = self.head(z).reshape(B, C, self.pred_len)
        y = (y * sig.permute(0, 2, 1) + mu.permute(0, 2, 1)).permute(0, 2, 1)
        return y.squeeze(-1) if was_2d else y


# Backward-compatible alias (state_dicts saved under the old name still load).
DualModalPhysicsModel = PhyTM
