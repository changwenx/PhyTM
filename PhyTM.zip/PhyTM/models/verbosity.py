"""
Verbosity switch
================
Global flag controlling whether modules emit diagnostic logs (DMD spectra,
GPT-2 stream construction, fallback notices, physics-parameter monitoring,
etc.). It is OFF by default so a standard run prints only the per-epoch line
and the final test metrics. Enable it with ``models.set_verbose(True)`` (or
``run_benchmark.py --verbose``) when debugging.
"""

_VERBOSE = False


def set_verbose(flag: bool) -> None:
    global _VERBOSE
    _VERBOSE = bool(flag)


def is_verbose() -> bool:
    return _VERBOSE
