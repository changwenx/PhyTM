"""
DMD-based Physics Information Extraction (precomputed spectrum)
===============================================================
Implements the physics-information modeling of PhyTM
(paper §"Physics Information Extraction via DMD").

The four DMD stages -- delay-embedded state construction, snapshot-matrix
construction, reduced-order operator estimation, and physical-spectrum
extraction -- are run **once** before training via ``init_from_data()``. The
resulting global spectrum {(alpha_k, omega_k)} is stored as buffers, where
alpha_k is the growth/decay rate and omega_k the oscillation frequency of the
k-th dominant dynamical mode.

During training, ``forward`` adds the learnable residual refinements
(Delta alpha, Delta omega) on top of the precomputed base spectrum with zero
SVD cost, yielding the refined spectrum (alpha_tilde, omega_tilde) that
conditions the textual and visual paths.

Usage:
    extractor = DMDPhysicsExtractor(n_modes=8)
    extractor.init_from_data(train_dataset)     # once, before training
    alpha, omega = extractor(B, C, device)      # per step, no SVD
"""
import torch
import torch.nn as nn

from .verbosity import is_verbose


class DMDPhysicsExtractor(nn.Module):
    def __init__(
        self,
        n_modes:    int   = 8,
        embed_len:  int   = 8,
        rank:       int   = None,
        delta_t:    float = 1.0,
        learnable:  bool  = True,
        eps:        float = 1e-6,
        alpha_clip: float = 5.0,
        omega_clip: float = 3.14159,
    ):
        super().__init__()
        self.K          = n_modes
        self.L          = embed_len
        self.r          = rank if rank is not None else min(2 * n_modes, embed_len)
        self.delta_t    = float(delta_t)
        self.eps        = eps
        self.alpha_clip = alpha_clip
        self.omega_clip = omega_clip

        # Global base spectrum (filled by init_from_data, shape [K])
        self.register_buffer('base_alpha', torch.zeros(n_modes))
        self.register_buffer('base_omega', torch.zeros(n_modes))
        self.register_buffer('_initialized', torch.tensor(False))

        # Learnable residual refinements (Delta alpha, Delta omega)
        if learnable:
            self.delta_alpha = nn.Parameter(torch.zeros(n_modes))
            self.delta_omega = nn.Parameter(torch.zeros(n_modes))
        else:
            self.register_buffer('delta_alpha', torch.zeros(n_modes))
            self.register_buffer('delta_omega', torch.zeros(n_modes))

    # ──────────────────────────────────────────────────────────────
    #   Precompute: called once before training
    # ──────────────────────────────────────────────────────────────
    @torch.no_grad()
    def init_from_data(self, dataset, n_samples: int = 512, device=None):
        """Sample sequences from the training set, run DMD once, and store the
        global spectrum into base_alpha / base_omega.

        Args:
            dataset:   TimeSeriesDataset whose __getitem__ returns (x [T,C], y, ...)
            n_samples: number of sequences used to estimate the global spectrum
            device:    compute device
        """
        import random
        if device is None:
            device = next(iter(self.parameters())).device

        total = len(dataset)
        idx   = random.sample(range(total), min(n_samples, total))

        # Collect sequences and flatten the channel axis: [n_samples * C, T]
        seqs = []
        for i in idx:
            x, *_ = dataset[i]            # x: [T, C] numpy or tensor
            if not isinstance(x, torch.Tensor):
                x = torch.from_numpy(x)
            x = x.float()               # [T, C]
            # per-channel standardisation (removes scale differences)
            x = (x - x.mean(0)) / (x.std(0) + 1e-6)
            seqs.append(x.T)            # [C, T]
        seqs = torch.cat(seqs, dim=0).to(device)  # [n_samples*C, T]

        alpha, omega = self._dmd_batch(seqs)       # [n_samples*C, K]

        # Use the median as the global spectrum (more robust than the mean,
        # unaffected by a few outlier sequences)
        base_a = alpha.median(dim=0).values        # [K]
        base_w = omega.median(dim=0).values        # [K]

        self.base_alpha.copy_(base_a)
        self.base_omega.copy_(base_w)
        self._initialized.fill_(True)

        if is_verbose():
            print(f"[DMD] global spectrum from {len(seqs)} sequences "
                  f"({n_samples} samples x C)")
            print(f"      base_alpha: {base_a.cpu().numpy().round(3)}")
            print(f"      base_omega: {base_w.cpu().numpy().round(3)}")

    # ──────────────────────────────────────────────────────────────
    #   DMD core (only invoked inside init_from_data)
    # ──────────────────────────────────────────────────────────────
    @torch.no_grad()
    def _dmd_batch(self, x: torch.Tensor):
        """Batched DMD: delay embedding -> snapshot pair -> reduced-order
        operator A_tilde -> eigenvalues mu_k -> (alpha_k, omega_k)."""
        B, T = x.shape
        L, r, K = self.L, self.r, self.K
        dtype, device = x.dtype, x.device
        M = T - L + 1

        # Delay-embedded state trajectory and the two shifted snapshot matrices
        S      = x.unfold(1, L, 1).transpose(1, 2).contiguous()
        X1, X2 = S[:, :, :-1], S[:, :, 1:]
        mean1  = X1.mean(dim=-1, keepdim=True)
        X1c, X2c = X1 - mean1, X2 - mean1

        # Reduced-order operator via truncated SVD of X1
        U_full, Sg_full, Vh_full = torch.linalg.svd(X1c, full_matrices=False)
        r_eff  = min(r, Sg_full.shape[-1])
        U_r    = U_full[:, :, :r_eff]
        Sg_r   = Sg_full[:, :r_eff]
        V_r    = Vh_full[:, :r_eff, :].conj().transpose(-2, -1)

        A_tilde = (U_r.transpose(-2, -1) @ X2c @ V_r) / (Sg_r.unsqueeze(-2) + self.eps)
        mu      = torch.linalg.eigvals(A_tilde)

        # Physical spectrum: alpha = ln|mu| / dt, omega = arg(mu) / dt
        mag   = mu.abs().clamp(min=self.eps)
        alpha = torch.log(mag) / self.delta_t
        omega = torch.angle(mu) / self.delta_t

        # Order modes by spectral magnitude (dominant modes first)
        order = torch.argsort(mag, dim=-1, descending=True)
        alpha = torch.gather(alpha, -1, order)
        omega = torch.gather(omega, -1, order)

        if r_eff >= K:
            alpha, omega = alpha[:, :K], omega[:, :K]
        else:
            pad   = K - r_eff
            zeros = alpha.new_zeros(B, pad)
            alpha = torch.cat([alpha, zeros], dim=-1)
            omega = torch.cat([omega, zeros], dim=-1)

        alpha = alpha.to(dtype).clamp(-self.alpha_clip, self.alpha_clip)
        omega = omega.to(dtype).clamp(-self.omega_clip, self.omega_clip)
        return alpha, omega

    # ──────────────────────────────────────────────────────────────
    #   Training-time forward: zero SVD, add learnable residual
    # ──────────────────────────────────────────────────────────────
    def forward(self, B: int, C: int, device: torch.device, dtype=torch.float32):
        """Return the refined spectrum broadcast to [B*C, K].

        alpha_tilde = base_alpha + Delta alpha,  omega_tilde = base_omega + Delta omega

        Args:
            B, C:   batch size and number of channels
            device: target device
            dtype:  floating point type
        Returns:
            alpha_tilde: [B*C, K]
            omega_tilde: [B*C, K]
        """
        if not self._initialized:
            raise RuntimeError(
                "DMDPhysicsExtractor is not initialised. "
                "Call extractor.init_from_data(train_dataset) before training."
            )

        a = (self.base_alpha + self.delta_alpha).to(dtype)   # [K]
        w = (self.base_omega + self.delta_omega).to(dtype)   # [K]

        a = a.clamp(-self.alpha_clip, self.alpha_clip)
        w = w.clamp(-self.omega_clip, self.omega_clip)

        # Broadcast to [B*C, K]
        BC = B * C
        return a.unsqueeze(0).expand(BC, -1), w.unsqueeze(0).expand(BC, -1)

    def physics_regularization(self) -> torch.Tensor:
        """Physics regulariser L_phys = ||Delta alpha||^2 + ||Delta omega||^2."""
        return self.delta_alpha.pow(2).sum() + self.delta_omega.pow(2).sum()
