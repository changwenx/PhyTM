#!/usr/bin/env python
"""
PhyTM benchmark runner
======================
The single top-level entry point for PhyTM. It sweeps a grid of datasets x
prediction horizons, runs each setting through ``engine.run_experiment``, and
writes the collected metrics to JSON and Markdown.

Console output is quiet by default: each run prints its per-epoch lines and a
final ``[Test]`` line, framed by a short ``[i/total]`` progress header. Pass
``--verbose`` to also surface the per-run diagnostics (device, data split,
adaptive policy, physics-spectrum monitoring, etc.).

Examples
--------
    # full benchmark grid (all datasets x {96,192,336,720})
    python run_benchmark.py

    # a quick subset
    python run_benchmark.py --datasets ETTh1,ETTh2 --pred_lens 96,192 --epochs 5

    # an ablation case from the paper (RQ3)
    python run_benchmark.py --ablation phys_no_mamba

    # run without the frozen GPT-2 textual stream
    python run_benchmark.py --no_gpt2

    # see the full diagnostics for one setting
    python run_benchmark.py --datasets weather --pred_lens 96 --verbose
"""

import os
import sys
import json
import argparse
from dataclasses import asdict

from config import Config, DATASETS, PRED_LENS, ABLATION_CASES
from engine import run_experiment


# ──────────────────────────────────────────────────────────────────
#   CLI
# ──────────────────────────────────────────────────────────────────
def parse_args():
    p = argparse.ArgumentParser(
        description="PhyTM benchmark runner",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    # ── grid / data ──────────────────────────────────────────────
    p.add_argument('--data_root', default=Config.data_root,
                   help='directory holding the dataset CSV files')
    p.add_argument('--datasets', default=",".join(DATASETS),
                   help='comma-separated dataset names')
    p.add_argument('--pred_lens', default=",".join(str(h) for h in PRED_LENS),
                   help='comma-separated prediction horizons')
    p.add_argument('--seq_len', type=int, default=Config.seq_len,
                   help='lookback window length')
    p.add_argument('--features', default=Config.features, choices=['M'],
                   help='only the multivariate (M) setting is supported')

    # ── model overrides ──────────────────────────────────────────
    p.add_argument('--d_model', type=int, default=Config.d_model)
    p.add_argument('--d_state', type=int, default=Config.d_state)
    p.add_argument('--n_text_layers', type=int, default=Config.n_text_layers)
    p.add_argument('--n_image_layers', type=int, default=Config.n_image_layers)
    p.add_argument('--n_cross_layers', type=int, default=Config.n_cross_layers)
    p.add_argument('--n_gtm_layers', type=int, default=Config.n_gtm_layers)
    p.add_argument('--n_heads', type=int, default=Config.n_heads)
    p.add_argument('--patch_len', type=int, default=Config.patch_len)
    p.add_argument('--patch_stride', type=int, default=Config.patch_stride)
    p.add_argument('--img_patch', type=int, default=Config.img_patch)

    # ── DMD physics extraction ───────────────────────────────────
    p.add_argument('--n_modes', type=int, default=Config.n_modes,
                   help='number of DMD modes K (each mode is a pair (alpha, omega))')
    p.add_argument('--dmd_embed_len', type=int, default=Config.dmd_embed_len,
                   help='DMD delay-embedding window length L')
    p.add_argument('--dmd_rank', type=int, default=Config.dmd_rank,
                   help='truncated SVD rank r (default 2K)')
    p.add_argument('--dmd_delta_t', type=float, default=Config.dmd_delta_t,
                   help='DMD sampling interval Delta t')
    p.add_argument('--lambda_phys', type=float, default=Config.lambda_phys,
                   help='weight of the physics regulariser L_phys')

    # ── textual path / GPT-2 ─────────────────────────────────────
    p.add_argument('--gpt2_path', default=Config.gpt2_path,
                   help='local path to the frozen GPT-2 weights')
    p.add_argument('--max_prompt_len', type=int, default=Config.max_prompt_len)
    p.add_argument('--no_gpt2', action='store_true',
                   help='disable the GPT-2 dual stream (physics-bias Transformer only)')

    # ── training ─────────────────────────────────────────────────
    p.add_argument('--batch_size', type=int, default=Config.batch_size)
    p.add_argument('--lr', type=float, default=Config.lr)
    p.add_argument('--weight_decay', type=float, default=Config.weight_decay)
    p.add_argument('--epochs', type=int, default=Config.epochs)
    p.add_argument('--patience', type=int, default=Config.patience)
    p.add_argument('--min_epochs', type=int, default=Config.min_epochs)
    p.add_argument('--grad_clip', type=float, default=Config.grad_clip)
    p.add_argument('--num_workers', type=int, default=Config.num_workers)
    p.add_argument('--device', default=Config.device)
    p.add_argument('--seed', type=int, default=Config.seed)
    p.add_argument('--save_dir', default=Config.save_dir)
    p.add_argument('--warmup_epochs', type=int, default=Config.warmup_epochs)
    p.add_argument('--no_lr_scale', action='store_true',
                   help='disable the automatic sqrt(96/seq_len) LR scaling')

    # ── ablation (RQ3) ───────────────────────────────────────────
    p.add_argument('--ablation', default='full', choices=ABLATION_CASES,
                   help='ablation case; full = complete PhyTM')

    # ── output / control ─────────────────────────────────────────
    p.add_argument('--output_json', default='benchmark_results.json')
    p.add_argument('--output_md', default='benchmark_results.md')
    p.add_argument('--verbose', action='store_true',
                   help='print per-run diagnostics in addition to epoch/test lines')
    p.add_argument('--dry_run', action='store_true',
                   help='list the planned runs and exit without training')
    return p.parse_args()


def make_config(args, dataset: str, pred_len: int) -> Config:
    """Build a per-run Config from the parsed CLI arguments."""
    return Config(
        data_root=args.data_root, dataset=dataset, features=args.features,
        seq_len=args.seq_len, pred_len=pred_len,
        patch_len=args.patch_len, patch_stride=args.patch_stride,
        img_patch=args.img_patch, img_size=None,
        d_model=args.d_model, d_state=args.d_state,
        n_text_layers=args.n_text_layers, n_image_layers=args.n_image_layers,
        n_cross_layers=args.n_cross_layers, n_gtm_layers=args.n_gtm_layers,
        n_heads=args.n_heads,
        n_modes=args.n_modes, dmd_embed_len=args.dmd_embed_len,
        dmd_rank=args.dmd_rank, dmd_delta_t=args.dmd_delta_t,
        lambda_phys=args.lambda_phys,
        gpt2_path=args.gpt2_path, max_prompt_len=args.max_prompt_len,
        use_gpt2=(not args.no_gpt2),
        batch_size=args.batch_size, lr=args.lr, weight_decay=args.weight_decay,
        epochs=args.epochs, patience=args.patience, min_epochs=args.min_epochs,
        grad_clip=args.grad_clip, num_workers=args.num_workers,
        device=args.device, seed=args.seed, save_dir=args.save_dir,
        warmup_epochs=args.warmup_epochs, no_lr_scale=args.no_lr_scale,
        ablation=args.ablation, verbose=args.verbose,
    )


# ──────────────────────────────────────────────────────────────────
#   result writers (called after every run -> Ctrl-C safe)
# ──────────────────────────────────────────────────────────────────
def write_json(path: str, results: list, meta: dict):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump({"meta": meta, "results": results}, f,
                  indent=2, ensure_ascii=False)


def write_markdown(path: str, results: list, meta: dict):
    lines = [
        f"# PhyTM benchmark results",
        "",
        f"- ablation: `{meta['ablation']}`",
        f"- seq_len: {meta['seq_len']}",
        f"- epochs: {meta['epochs']}",
        f"- use_gpt2: {meta['use_gpt2']}",
        "",
        "| Dataset | pred_len | val MSE | test MSE | test MAE | status |",
        "|---------|---------:|--------:|---------:|---------:|--------|",
    ]
    for r in results:
        if r.get("status") == "ok":
            lines.append(
                f"| {r['dataset']} | {r['pred_len']} | {r['val_MSE']:.4f} | "
                f"{r['test_MSE']:.4f} | {r['test_MAE']:.4f} | ok |")
        else:
            lines.append(
                f"| {r['dataset']} | {r['pred_len']} | - | - | - | "
                f"FAILED: {r.get('error', '')} |")
    lines.append("")
    with open(path, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))


def print_summary(results: list):
    print("\n" + "=" * 64)
    print(f"{'Dataset':<16}{'pl':>5}{'val MSE':>11}{'test MSE':>11}{'test MAE':>11}")
    print("-" * 64)
    for r in results:
        if r.get("status") == "ok":
            print(f"{r['dataset']:<16}{r['pred_len']:>5}"
                  f"{r['val_MSE']:>11.4f}{r['test_MSE']:>11.4f}{r['test_MAE']:>11.4f}")
        else:
            print(f"{r['dataset']:<16}{r['pred_len']:>5}{'FAILED':>33}")
    print("=" * 64)


# ──────────────────────────────────────────────────────────────────
#   main
# ──────────────────────────────────────────────────────────────────
def main():
    args = parse_args()
    datasets  = [d.strip() for d in args.datasets.split(',') if d.strip()]
    pred_lens = [int(h) for h in args.pred_lens.split(',') if h.strip()]
    plan = [(d, h) for d in datasets for h in pred_lens]
    total = len(plan)

    meta = dict(ablation=args.ablation, seq_len=args.seq_len,
                epochs=args.epochs, use_gpt2=(not args.no_gpt2),
                datasets=datasets, pred_lens=pred_lens)

    if args.dry_run:
        print(f"Planned {total} run(s) [ablation={args.ablation}, "
              f"seq_len={args.seq_len}, epochs={args.epochs}]:")
        for i, (d, h) in enumerate(plan, 1):
            print(f"  [{i}/{total}] {d}  pred_len={h}")
        return

    results = []
    for i, (dataset, pred_len) in enumerate(plan, 1):
        print(f"\n[{i}/{total}] {dataset}  pred_len={pred_len}  "
              f"(ablation={args.ablation})")
        cfg = make_config(args, dataset, pred_len)
        try:
            res = run_experiment(cfg)
        except Exception as e:  # one failure must not abort the whole sweep
            res = dict(dataset=dataset, seq_len=args.seq_len, pred_len=pred_len,
                       status="failed", error=f"{type(e).__name__}: {e}")
            print(f"  [FAILED] {type(e).__name__}: {e}")
        results.append(res)
        # persist after every run so an interruption still leaves valid files
        write_json(args.output_json, results, meta)
        write_markdown(args.output_md, results, meta)

    print_summary(results)
    print(f"\nresults written to {args.output_json} and {args.output_md}")


if __name__ == '__main__':
    main()
