# PhyTM：物理信息驱动的三模态时序预测框架

PhyTM 将动态模态分解（DMD）抽取的物理谱（衰减率 α、振荡频率 ω）注入到三条模态通路中，
实现数据驱动建模与物理动力学约束的统一：

- **文本通路**：物理信息双流注意力 Transformer（冻结 GPT-2 语义流 + patch 流，DMD 偏置注入注意力 logits）
- **视觉通路**：GAF 图像 + 物理结构化状态空间 Mamba（状态转移矩阵由 DMD 谱构造，保证长程稳定性）
- **数值通路**：混合 Transformer-Mamba，保留原始时序保真度

三条通路输出统一维度的表征，经门控融合后由两层 MLP 预测头映射到预测窗口。

---

## 目录结构

```
PhyTM/
├── run_benchmark.py        # 唯一的顶层运行入口（基准测试 + 消融实验）
├── requirements.txt
├── README.md
├── config/                 # 配置与自适应策略
│   ├── __init__.py
│   └── default.py          # Config 数据类、数据集/序列长度自适应策略、消融用例
├── models/                 # 模型组件
│   ├── __init__.py
│   ├── verbosity.py        # 日志开关（默认静默）
│   ├── physics_extractor.py# DMD 物理谱提取（base_α/base_ω + 可学习残差 Δα/Δω）
│   ├── text_modal.py       # 文本通路：物理信息双流注意力 Transformer
│   ├── image_modal.py      # 视觉通路：GAF + 物理结构化状态空间 Mamba
│   ├── numerical_path.py   # 数值通路：混合 Transformer-Mamba
│   └── phytm.py            # PhyTM 主模型（三模态门控融合）
├── data/                   # 数据加载
│   ├── __init__.py
│   └── dataset.py          # TimeSeriesDataset（ETT 12-4-4 切分，其余 7:1:2）
├── engine/                 # 训练引擎
│   ├── __init__.py
│   └── trainer.py          # run_experiment()：单组实验的训练/验证/测试
└── experiments/            # 实验脚本（消融 / 灵敏度 / 物理可视化）
    ├── __init__.py
    ├── _common.py          # 实验脚本共用的命令行参数与 Config 构造
    ├── run_ablation.py     # 消融实验：跑全部消融用例并汇总对比表
    ├── run_sensitivity.py  # 灵敏度实验：扫描 K / d_model / dmd_embed_len
    ├── plot_sensitivity.py # 灵敏度图（读扫描结果，或用论文数据复现）
    └── plot_physics.py     # 物理可视化：从 checkpoint 提取谱并绘制 4 张图
```

数据文件需放在 `--data_root` 指向的目录下，命名为 `<数据集名>.csv`（含 `date` 列 + 各通道数值列）。

---

## 安装

```bash
pip install -r requirements.txt
```

> Mamba 官方 CUDA 内核为可选项。若未安装 `mamba-ssm`，视觉通路会自动切换为纯 PyTorch 并行扫描实现，无需编译 GPU 算子。

---

## 运行

默认情况下，运行过程**只打印每个 epoch 与最终的 test MSE/MAE**，不会输出 GPT、DMD、Adaptive、Optimizer 等任何诊断信息。

```bash
# 跑完整基准（全部数据集 × {96,192,336,720}）
cd PhyTM
python run_benchmark.py --data_root /你的/数据目录
```

```bash
# 只跑部分数据集和预测步长，并指定较少的 epoch
python run_benchmark.py --data_root /你的/数据目录 \
    --datasets ETTh1,ETTh2 --pred_lens 96,192 --epochs 5
```

```bash
# 论文 RQ3 的消融实验（physics 组件 / 三模态路径）
python run_benchmark.py --data_root /你的/数据目录 --ablation phys_no_mamba
```

```bash
# 不使用 GPT-2 文本流（退化为纯物理偏置 Transformer）
python run_benchmark.py --data_root /你的/数据目录 --no_gpt2
```

```bash
# 需要查看完整诊断信息时，加 --verbose
python run_benchmark.py --data_root /你的/数据目录 \
    --datasets weather --pred_lens 96 --verbose
```

```bash
# 只列出将要运行的实验，不实际训练
python run_benchmark.py --datasets ETTh1,weather --pred_lens 96,192 --dry_run
```

运行结束后，结果会写入 `benchmark_results.json` 与 `benchmark_results.md`（每跑完一组就落盘一次，中途 Ctrl-C 也能保留已完成的结果）。

---

## 消融用例（`--ablation`）

| 取值 | 含义 |
|------|------|
| `full` | 完整 PhyTM（DMD + 物理 Transformer + 物理 Mamba） |
| `phys_none` | 两条通路均去除物理（退化为标准模块） |
| `phys_no_mamba` | 仅文本通路保留物理 |
| `phys_no_trans` | 仅视觉通路保留物理 |
| `no_text` / `no_image` / `no_num` | 分别移除文本 / 视觉 / 数值通路 |

---

## 实验脚本（`experiments/`）

所有实验脚本都可以从包根目录直接运行，默认同样静默（只打印 epoch + test 行）。

### 1. 消融实验

`run_benchmark.py --ablation <用例>` 跑单个用例；若要一次跑完全部用例并自动汇总成对比表，用 `run_ablation.py`：

```bash
# ETT 四个数据集，pred_len=96，跑全部消融用例
python experiments/run_ablation.py --data_root /你的/数据目录 \
    --datasets ETTh1,ETTh2,ETTm1,ETTm2 --pred_lens 96
```

```bash
# 只跑部分用例
python experiments/run_ablation.py --data_root /你的/数据目录 \
    --cases full,phys_none,no_text --datasets ETTh1 --pred_lens 96,192
```

结果写入 `ablation_results.json` 与 `ablation_results.md`（后者按用例透视成 Test MSE / Test MAE 两张表）。

### 2. 灵敏度实验

`run_sensitivity.py` 在默认配置附近逐个扫描超参（K=n_modes、d_model、dmd_embed_len），记录每个取值的 MSE/MAE：

```bash
# 在 ETT 数据集上扫描全部三个超参（pred_len=96）
python experiments/run_sensitivity.py --data_root /你的/数据目录
```

```bash
# 只扫描 K，并自定义网格
python experiments/run_sensitivity.py --data_root /你的/数据目录 \
    --params K --K_grid 4,8,16
```

然后绘图（读上一步的扫描结果）：

```bash
python experiments/plot_sensitivity.py --input sensitivity_results.json
```

如果暂时没有扫描结果，直接运行 `plot_sensitivity.py`（不带 `--input`）会用论文里报告的 ETT 数值复现该图，方便先看版式：

```bash
python experiments/plot_sensitivity.py
```

### 3. 物理可视化

`run_benchmark.py` 跑完后，`--save_dir` 里会留下 `<数据集>_M_sl<sl>_pl<pl>.pt` 的 checkpoint。`plot_physics.py` 从这些 checkpoint 中提取学到的阻尼谐振子谱（α、ω、|β|），绘制四张图：

```bash
python experiments/plot_physics.py --ckpt_dir checkpoints_benchmark --out_dir figs
```

输出：
- `fig_pole_spectrum`：连续时间极点图（s 平面）+ 离散时间特征值图（z 平面，全部落在单位圆内 → 稳定）
- `fig_pole_facets`：每个数据集单独一张 z 平面"频率指纹"
- `fig_basis_all`：各数据集学到的阻尼振荡基 `exp(α_k t)·cos(ω_k t)`
- `fig_heatmaps`：衰减率 α 与角频率 ω 的双热力图

每张图都同时输出 `.png` 与 `.pdf`。

---

## 训练目标

```
L = L_pred + λ_phys · L_phys
```

其中 `L_phys = ||Δα||² + ||Δω||²` 约束可学习残差不偏离 DMD 初始化的谱。数据集自适应策略会针对非平稳数据集
（如 exchange_rate）自动将 `λ_phys` 置零；大变量数据集（electricity / traffic）会自动降低容量并增大正则。
所有自适应逻辑与原始训练脚本数值完全一致。
