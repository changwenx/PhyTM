"""Dataset package."""
from .dataset import TimeSeriesDataset

__all__ = ["TimeSeriesDataset"]
