"""
Time-series dataset loader (paper §"Problem Definition")
========================================================
Loads a multivariate series X in R^{L x N} and builds (lookback, horizon) pairs.

- features='M' : multivariate input + multivariate output (default; main tables)
- features='S' : multivariate input + single-variable output (target only)
- features='U' : single-variable input + single-variable output (target only)

Standard splits: ETT* uses the Informer 12-4-4 month split; others use 7:1:2.
Statistics are computed on the training segment only (no leakage), and val/test
are normalised with the training statistics.
"""
import os
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


class TimeSeriesDataset(Dataset):
    def __init__(self, root: str, dataset: str, flag: str = 'train',
                 seq_len: int = 96, pred_len: int = 96,
                 target=None, features: str = 'M', scale: bool = True):
        assert flag in ('train', 'val', 'test')
        assert features in ('M', 'S', 'U')
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.features = features
        flag_idx = {'train': 0, 'val': 1, 'test': 2}[flag]

        # —— read CSV ——
        path = os.path.join(root, f"{dataset}.csv")
        df = pd.read_csv(path)
        if 'date' in df.columns:
            df = df.drop(columns=['date'])

        # —— select columns by features ——
        if features == 'M':
            data = df.values.astype(np.float32)                  # [T, C]
        else:  # 'S' / 'U' : single column
            if target is not None and target in df.columns:
                data = df[[target]].values.astype(np.float32)
            else:
                data = df.iloc[:, [-1]].values.astype(np.float32)

        # record the target column position under the M setting
        if features == 'M' and target is not None and target in df.columns:
            self.target_idx = list(df.columns).index(target)
        else:
            self.target_idx = 0

        n, C = data.shape

        # —— standard split ——
        ds = dataset.lower()
        if ds.startswith('etth'):
            border1s = [0,
                        12*30*24 - seq_len,
                        12*30*24 + 4*30*24 - seq_len]
            border2s = [12*30*24,
                        12*30*24 + 4*30*24,
                        12*30*24 + 8*30*24]
        elif ds.startswith('ettm'):
            border1s = [0,
                        12*30*24*4 - seq_len,
                        12*30*24*4 + 4*30*24*4 - seq_len]
            border2s = [12*30*24*4,
                        12*30*24*4 + 4*30*24*4,
                        12*30*24*4 + 8*30*24*4]
        else:
            train_end = int(n * 0.7)
            val_end = int(n * 0.9)
            border1s = [0, train_end - seq_len, val_end - seq_len]
            border2s = [train_end, val_end, n]

        # —— normalise with training-segment statistics (no leakage) ——
        if scale:
            train_part = data[border1s[0]:border2s[0]]            # [T_tr, C]
            self.mean = train_part.mean(axis=0).astype(np.float32)
            self.std = (train_part.std(axis=0) + 1e-6).astype(np.float32)
            data = (data - self.mean) / self.std
        else:
            self.mean = np.zeros(C, dtype=np.float32)
            self.std = np.ones(C, dtype=np.float32)

        self.data = data[border1s[flag_idx]:border2s[flag_idx]].astype(np.float32)
        self.n_channels = C

    def __len__(self):
        return len(self.data) - self.seq_len - self.pred_len + 1

    def __getitem__(self, idx):
        x = self.data[idx: idx + self.seq_len]                    # [seq_len, C]
        y = self.data[idx + self.seq_len: idx + self.seq_len + self.pred_len]
        # per-channel statistics of the current window (used to build prompts)
        stats = np.stack([
            x.mean(axis=0),    # [C]
            x.std(axis=0),     # [C]
            x.min(axis=0),     # [C]
            x.max(axis=0),     # [C]
        ], axis=0).astype(np.float32)                              # [4, C]
        return (torch.from_numpy(x),
                torch.from_numpy(y),
                torch.from_numpy(stats),
                torch.tensor(idx, dtype=torch.long))
