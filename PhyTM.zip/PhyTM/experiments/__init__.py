"""PhyTM experiment scripts: ablation study, sensitivity sweep, physics visualization."""
