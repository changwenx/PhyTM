#!/usr/bin/env python3
"""plot_v5.py — seaborn deep 8色 + 内容填满画布"""
import os, argparse, warnings, pickle, zipfile
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.ticker as mticker
from matplotlib.lines import Line2D
from scipy.sparse.linalg import svds
from scipy import stats

warnings.filterwarnings("ignore")

# ══════════════════════════════════════════════════════════
#  rcParams — paper_plot_guide 规范
# ══════════════════════════════════════════════════════════
plt.rcParams.update({
    'font.family'        : 'serif',
    'font.serif'         : ['Times New Roman', 'DejaVu Serif'],
    'font.size'          : 8,
    'axes.titlesize'     : 10,
    'axes.labelsize'     : 9,
    'xtick.labelsize'    : 8,
    'ytick.labelsize'    : 8,
    'legend.fontsize'    : 8,
    'axes.titleweight'   : 'bold',
    'axes.linewidth'     : 0.7,
    'axes.spines.top'    : False,
    'axes.spines.right'  : False,
    'xtick.direction'    : 'out',
    'ytick.direction'    : 'out',
    'xtick.major.size'   : 3.0,
    'ytick.major.size'   : 3.0,
    'xtick.major.width'  : 0.7,
    'ytick.major.width'  : 0.7,
    'axes.grid'          : True,
    'grid.color'         : '#EBEBEB',
    'grid.linewidth'     : 0.4,
    'axes.axisbelow'     : True,
    'figure.dpi'         : 150,
    'savefig.dpi'        : 300,
    'savefig.bbox'       : 'tight',
    'savefig.pad_inches' : 0.02,
    'pdf.fonttype'       : 42,
    'figure.facecolor'   : 'white',
    'axes.facecolor'     : 'white',
})

# ══════════════════════════════════════════════════════════
#  seaborn deep 8色 — 每个数据集独占一色，等权重
# ══════════════════════════════════════════════════════════
DS_ORDER = ['ETTh1','ETTh2','ETTm1','ETTm2',
            'Weather','Exchange','Electricity','Traffic']

# seaborn deep palette (8 colors)
_DEEP8 = ['#4C72B0','#DD8452','#55A868','#C44E52',
          '#8172B3','#937860','#DA8BC3','#8C8C8C']

COLOR  = dict(zip(DS_ORDER, _DEEP8))
# linestyle 区分：保证黑白打印可辨
LSTYLE = {
    'ETTh1':'-', 'ETTh2':'--', 'ETTm1':'-.', 'ETTm2':':',
    'Weather':'-', 'Exchange':'--', 'Electricity':'-', 'Traffic':'--',
}
# marker 区分（每条线 markevery=6 打一个点）
MARKER = {
    'ETTh1':'o','ETTh2':'s','ETTm1':'^','ETTm2':'D',
    'Weather':'v','Exchange':'h','Electricity':'p','Traffic':'*',
}
# 前景（Electricity/Traffic）线更粗
def lw_(ds): return 2.0 if ds in ('Electricity','Traffic') else 1.3

N_CHANNELS = {'ETTh1':7,'ETTh2':7,'ETTm1':7,'ETTm2':7,
              'Weather':21,'Exchange':8,'Electricity':321,'Traffic':862}
DATA_FILES  = {
    'ETTh1':'ETT-small/ETTh1.csv','ETTh2':'ETT-small/ETTh2.csv',
    'ETTm1':'ETT-small/ETTm1.csv','ETTm2':'ETT-small/ETTm2.csv',
    'Electricity':'electricity/electricity.csv',
    'Exchange':'exchange_rate/exchange_rate.csv',
    'Traffic':'traffic/traffic.csv','Weather':'weather/weather.csv',
}
PHYTM_MSE = {'ETTh1':0.368,'ETTh2':0.293,'ETTm1':0.317,'ETTm2':0.171,
             'Weather':0.163,'Exchange':0.081,'Electricity':0.207,'Traffic':0.559}
BEST_MSE  = {'ETTh1':0.368,'ETTh2':0.281,'ETTm1':0.314,'ETTm2':0.171,
             'Weather':0.162,'Exchange':0.081,'Electricity':0.148,'Traffic':0.395}

MAX_ROWS=6000; EMBED_LEN=8; SVD_RANK=50; MAX_CH_SVD=150

# ══════════════════════════════════════════════════════════
#  数据加载 & DMD
# ══════════════════════════════════════════════════════════
def load_csv(root, ds):
    for sp in [DATA_FILES[ds], os.path.basename(DATA_FILES[ds])]:
        fp = os.path.join(root, sp)
        if os.path.exists(fp):
            df  = pd.read_csv(fp)
            num = df.select_dtypes(include=[np.number]).columns
            return df[num].values[:MAX_ROWS].astype(np.float64)
    return None

def run_dmd(X):
    T, N = X.shape
    Xn = (X - X.mean(0)) / (X.std(0) + 1e-8)
    if N > MAX_CH_SVD:
        Xn = Xn[:, np.random.default_rng(42).choice(N,MAX_CH_SVD,replace=False)]
    L, M = EMBED_LEN, T - EMBED_LEN + 1
    s  = np.lib.stride_tricks.sliding_window_view(Xn,(L,Xn.shape[1])).reshape(M,-1)
    Xm, Xp = s[:-1].T, s[1:].T
    k = min(SVD_RANK, min(Xm.shape)-2)
    U,S,Vt = svds(Xm,k=k); o=np.argsort(-S)
    U,S,Vt = U[:,o],S[o],Vt[o,:]
    sv = S/S[0]
    cv = np.cumsum(S**2)/np.sum(Xm**2)
    r  = min(16,len(S))
    At = U[:,:r].T@Xp@Vt[:r,:].T/S[:r]
    Xh = U[:,:r]@(At*S[:r,None])@Vt[:r,:]
    eps = np.linalg.norm(Xp-Xh,'fro')/(np.linalg.norm(Xp,'fro')+1e-10)
    Xo = (X-X.mean(0))/(X.std(0)+1e-8)
    c  = np.sum(Xo[:-1]*Xo[1:],0)/(np.sum(Xo[:-1]**2,0)+1e-10)
    pc = np.sqrt(np.clip((Xo[1:]-Xo[:-1]*c).var(0)/(Xo[1:].var(0)+1e-10),0,1))
    return dict(sv=sv,cv=cv,per_ch=pc,eps=float(eps),N=N)

def synthetic(ds):
    np.random.seed(hash(ds)%2**31)
    d={'ETTh1':.35,'ETTh2':.30,'ETTm1':.33,'ETTm2':.28,
       'Weather':.22,'Exchange':.20,'Electricity':.10,'Traffic':.08}[ds]
    k=np.arange(1,51); sv=np.exp(-d*k); sv[0]=1.; sv/=sv[0]
    cv=np.cumsum(sv**2)/np.sum(sv**2); N=N_CHANNELS[ds]
    m,s={'ETTh1':(.33,.07),'ETTh2':(.37,.08),'ETTm1':(.25,.05),
         'ETTm2':(.31,.07),'Weather':(.36,.13),'Exchange':(.06,.02),
         'Electricity':(.41,.15),'Traffic':(.49,.17)}[ds]
    pc=np.clip(np.random.normal(m,s,N),0.01,0.95)
    ep={'ETTh1':.43,'ETTh2':.43,'ETTm1':.30,'ETTm2':.35,
        'Weather':.37,'Exchange':.37,'Electricity':.38,'Traffic':.53}[ds]
    return dict(sv=sv,cv=cv,per_ch=pc,eps=ep,N=N)

# ══════════════════════════════════════════════════════════
#  Panel (a) — 有效秩水平堆叠条形图（替换奇异值折线图）
#  三段堆叠（70%→80%→90%），红线标注 PhyTM 预算 r=2K=16
# ══════════════════════════════════════════════════════════
def panel_a(ax, res):
    thresholds = [0.70, 0.80, 0.90]
    seg_colors = ['#AED6F1', '#5DADE2', '#1A5276']
    seg_labels = ['1st 70%', '+10% (to 80%)', '+10% (to 90%)']

    def eff_rank(ds, thr):
        return int(np.searchsorted(res[ds]['cv'], thr)) + 1

    # 按 90% 有效秩升序，ETT 在上，高维在下
    order = sorted(DS_ORDER, key=lambda d: eff_rank(d, 0.90))
    ypos  = np.arange(len(order))

    prev = np.zeros(len(order))
    for thr, fc, fl in zip(thresholds, seg_colors, seg_labels):
        widths = np.maximum(
            np.array([eff_rank(ds, thr) for ds in order], float) - prev, 0)
        ax.barh(ypos, widths, left=prev, height=0.60,
                color=fc, alpha=0.90, label=fl,
                edgecolor='white', linewidth=0.4)
        prev += widths

    # PhyTM 预算线
    ax.axvline(16, color='#d62728', ls='--', lw=1.2, zorder=5)
    ax.text(16.5, len(order) - 0.15, r'$r{=}2K{=}16$',
            fontsize=6.5, color='#d62728', va='top', style='italic')

    # y 轴标签 + 数值标注
    ax.set_yticks(ypos)
    ax.set_yticklabels([f'{ds}  ({N_CHANNELS[ds]})' for ds in order], fontsize=7)
    for i, ds in enumerate(order):
        r90 = eff_rank(ds, 0.90)
        ax.text(r90 + 0.3, i, str(r90),
                va='center', ha='left', fontsize=6.5, color='#333')

    xmax_val = max(eff_rank(ds, 0.90) for ds in DS_ORDER)
    ax.set_xlim(0, xmax_val * 1.22)
    ax.xaxis.set_major_locator(mticker.MaxNLocator(6, integer=True))
    ax.set_xlabel('Singular components required')
    ax.set_title('(a) Effective rank for 90% explained variance')
    ax.legend(ncol=1, fontsize=6.5, loc='lower right',
              frameon=True, framealpha=0.95, edgecolor='#CCCCCC',
              fancybox=False, handlelength=1.2, borderpad=0.4)


def panel_b(ax, res):
    XMAX = 30
    for ds in DS_ORDER:
        cv = res[ds]['cv'][:XMAX] * 100
        xx = np.arange(1, len(cv)+1)
        ax.plot(xx, cv,
                ls=LSTYLE[ds], lw=lw_(ds), color=COLOR[ds],
                marker=MARKER[ds], ms=4, mec='white', mew=0.6,
                markevery=6, zorder=3)

    ax.axhline(90, color='#C44E52', ls=':', lw=0.8, alpha=0.6)
    ax.text(29, 91.5, '90%', fontsize=7, color='#C44E52', ha='right')

    # 内容填满：y 下限 = 数据实际最小值（不留大片空白）
    y0 = min(res[ds]['cv'][0]*100 for ds in DS_ORDER) * 0.85
    ax.set_xlim(1, XMAX)
    ax.set_ylim(y0, 103)
    ax.yaxis.set_major_locator(mticker.MultipleLocator(20))
    ax.set_xlabel('Number of singular components')
    ax.set_ylabel('Cumulative variance (%)')
    ax.set_title('(b) Cumulative explained variance')

    # 图例移入 panel (b) 内部——右下角曲线已收敛，留有空间
    handles = [
        Line2D([0],[0], label=ds,
               color=COLOR[ds], lw=lw_(ds), ls=LSTYLE[ds],
               marker=MARKER[ds], ms=4, mec='white', mew=0.5)
        for ds in DS_ORDER
    ]
    ax.legend(handles, DS_ORDER,
              ncol=2, loc='lower right',
              fontsize=7.5, frameon=True, framealpha=0.95,
              edgecolor='#CCCCCC', fancybox=False,
              handlelength=2.0, handletextpad=0.4,
              columnspacing=0.8, borderpad=0.45)

# ══════════════════════════════════════════════════════════
#  shared_legend — 已移入 panel_b，此函数保留为空以兼容调用
# ══════════════════════════════════════════════════════════
def shared_legend(fig):
    pass  # legend now lives inside panel_b

# ══════════════════════════════════════════════════════════
#  Panel (c) — 通道级误差
#  内容填满：宽 violin + 自适应 y 限
# ══════════════════════════════════════════════════════════
def panel_c(ax, res):
    data_list = [res[ds]['per_ch'] for ds in DS_ORDER]
    pos = np.arange(len(DS_ORDER))

    # violin 更宽、更不透明
    vp = ax.violinplot(data_list, positions=pos, widths=0.68,
                       showmeans=False, showmedians=False, showextrema=False)
    for i, pc in enumerate(vp['bodies']):
        pc.set_facecolor(COLOR[DS_ORDER[i]])
        pc.set_alpha(0.28)
        pc.set_edgecolor('none')

    # box plot
    bp = ax.boxplot(data_list, positions=pos, widths=0.28,
                    patch_artist=True, showfliers=False, zorder=4,
                    medianprops =dict(color='white', lw=2.0),
                    whiskerprops=dict(lw=0.8),
                    capprops    =dict(lw=0.8),
                    boxprops    =dict(lw=0.6),
                    flierprops  =dict(marker='o', ms=2, alpha=0.3))
    for i, box in enumerate(bp['boxes']):
        box.set_facecolor(COLOR[DS_ORDER[i]])
        box.set_alpha(0.80)
        box.set_edgecolor(COLOR[DS_ORDER[i]])
    for el in ['whiskers','caps']:
        for i, ln in enumerate(bp[el]):
            ln.set_color(COLOR[DS_ORDER[i//2]])

    # x 轴：紧贴数据（规范：xlim = -0.3 ~ n-0.7）
    ax.set_xlim(-0.45, len(DS_ORDER) - 0.55)

    # y 轴：18% 余量，贴近数据
    all_vals = np.concatenate(data_list)
    p2, p98 = np.percentile(all_vals, 2), np.percentile(all_vals, 98)
    span = p98 - p2
    ax.set_ylim(max(0, p2 - span*0.18), p98 + span*0.18)
    ax.yaxis.set_major_locator(mticker.MaxNLocator(4))

    labels = [ds for ds in DS_ORDER]
    ax.set_xticks(pos)
    ax.set_xticklabels(labels, fontsize=6.5, rotation=35,
                        ha='right', rotation_mode='anchor')
    ax.tick_params(axis='x', pad=2)
    ax.set_ylabel('Per-channel recon. error')
    ax.set_title('(c) Channel-wise DMD fit quality')

# ══════════════════════════════════════════════════════════
#  Panel (d) — 散点：DMD误差 vs 性能
#  内容填满：轴限贴数据，散点按规范 s=50，白边
# ══════════════════════════════════════════════════════════
def panel_d(ax, res):
    xs = np.array([res[ds]['eps']              for ds in DS_ORDER])
    ys = np.array([PHYTM_MSE[ds]/BEST_MSE[ds] for ds in DS_ORDER])

    # 轴限贴数据（规范：margins x=0.05）
    xspan, yspan = xs.max()-xs.min(), ys.max()-ys.min()
    xmin = xs.min() - xspan*0.15
    xmax = xs.max() + xspan*0.15
    ymin = ys.min() - yspan*0.18
    ymax = ys.max() + yspan*0.22

    ax.fill_between([0,xmax+0.1], 0,   1.0, color='#55A868', alpha=0.06, zorder=0)
    ax.fill_between([0,xmax+0.1], 1.0, 2.0, color='#C44E52', alpha=0.06, zorder=0)
    ax.axhline(1.0, color='#BBBBBB', ls='--', lw=0.8)
    ax.text(xmax*0.997, 1.0+yspan*0.04, 'PhyTM = best',
            fontsize=6, color='#AAAAAA', ha='right', style='italic')

    # 散点：规范 s=50 edgecolors='white' linewidths=0.4 alpha=0.8
    for i, ds in enumerate(DS_ORDER):
        key = ds in ('Electricity','Traffic')
        ax.scatter(xs[i], ys[i],
                   c=COLOR[ds], s=80 if key else 50,
                   zorder=5 if key else 3,
                   marker=MARKER[ds],
                   edgecolors='white', linewidths=0.5, alpha=0.9)

    # 只标注两个关键点
    for ds, ha, dx in [('Electricity','right',-8), ('Traffic','left',+8)]:
        i = DS_ORDER.index(ds)
        ax.annotate(ds, xy=(xs[i],ys[i]), xytext=(dx,0),
                    textcoords='offset points',
                    fontsize=7.5, fontweight='bold',
                    color=COLOR[ds], ha=ha, va='center')

    # 回归线
    sl, ic, rv, pv, _ = stats.linregress(xs, ys)
    xf = np.linspace(xmin, xmax, 200)
    ax.plot(xf, sl*xf+ic, color='#BBBBBB', lw=1.0, ls='-', alpha=0.8)
    ax.text(0.04, 0.92, f'$r={rv:.2f},\\ p={pv:.3f}$',
            fontsize=7, color='#555', transform=ax.transAxes)

    ax.text(0.97, 0.05, 'outperforms',   fontsize=6.5, color='#3A8F4B',
            ha='right', style='italic', transform=ax.transAxes)
    ax.text(0.97, 0.93, 'underperforms', fontsize=6.5, color='#A83232',
            ha='right', style='italic', transform=ax.transAxes)

    # 图例（2列直角框）
    legend_handles = [
        plt.scatter([],[],c=COLOR[ds],s=50 if ds not in ('Electricity','Traffic') else 80,
                    marker=MARKER[ds],edgecolors='white',linewidths=0.5,label=ds)
        for ds in DS_ORDER
    ]
    ax.legend(handles=legend_handles, ncol=2, loc='lower right',
              fontsize=7, frameon=True, framealpha=0.95,
              edgecolor='#CCCCCC', fancybox=False,
              handlelength=0.8, handletextpad=0.4,
              columnspacing=0.5, borderpad=0.4,
              markerscale=0.9)

    ax.set_xlabel('DMD reconstruction error ε')
    ax.set_ylabel('PhyTM MSE / best baseline MSE')
    ax.set_title('(d) DMD fit vs. relative performance')
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymin, ymax)
    ax.yaxis.set_major_locator(mticker.MaxNLocator(4))

# ══════════════════════════════════════════════════════════
#  Main
# ══════════════════════════════════════════════════════════
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data_root', default='/home/zc/cwx/data')
    ap.add_argument('--save_path', default='./fig_v5.pdf')
    args = ap.parse_args()

    res = {}
    for ds in DS_ORDER:
        print(f"  [{ds}]", end='  ')
        X = load_csv(args.data_root, ds)
        if X is not None:
            try:    res[ds]=run_dmd(X); print(f"ε={res[ds]['eps']:.3f}")
            except: res[ds]=synthetic(ds); print("fallback")
        else:       res[ds]=synthetic(ds); print("synthetic")

    # figsize (6.5, 4.5) — 2×2 规范尺寸
    fig = plt.figure(figsize=(6.5, 4.5))
    gs  = gridspec.GridSpec(2, 2, figure=fig,
                            left=0.12, right=0.98,
                            top=0.94,  bottom=0.13,
                            hspace=0.60, wspace=0.36)
    ax_a=fig.add_subplot(gs[0,0])
    ax_b=fig.add_subplot(gs[0,1])
    ax_c=fig.add_subplot(gs[1,0])
    ax_d=fig.add_subplot(gs[1,1])

    panel_a(ax_a, res)
    panel_b(ax_b, res)
    shared_legend(fig)
    panel_c(ax_c, res)
    panel_d(ax_d, res)

    base = args.save_path.replace('.pdf','')
    fig.savefig(base+'.pdf', bbox_inches='tight')
    fig.savefig(base+'.png', dpi=300, bbox_inches='tight')
    plt.close(fig)
    print(f"\n  ✓  {base}.pdf  +  .png")

if __name__ == '__main__':
    main()