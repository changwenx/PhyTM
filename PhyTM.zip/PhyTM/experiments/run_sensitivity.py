#!/usr/bin/env python
"""
PhyTM hyperparameter sensitivity sweep
======================================
Sweeps one hyperparameter at a time around the defaults and records the test
MSE/MAE for each value, for each dataset (at a single prediction horizon).
Three parameters are supported, matching the paper's sensitivity study:

    K  ->  n_modes        number of DMD modes        grid 4 / 8 / 16 / 32
    D  ->  d_model        model width                grid 32 / 64 / 128 / 256
    E  ->  dmd_embed_len  DMD delay-embedding length grid 4 / 8 / 16 / 32

The result JSON is consumed by ``experiments/plot_sensitivity.py`` to render the
sensitivity figure. ``opt`` (the per-dataset best index, used to centre each
curve at 0%) is computed from the swept MSE.

Examples
--------
    # sweep all three params on the ETT datasets at pred_len 96
    python experiments/run_sensitivity.py --data_root /path/to/data

    # sweep only K, with custom grid
    python experiments/run_sensitivity.py --data_root /path/to/data \
        --params K --K_grid 4,8,16

Then plot:
    python experiments/plot_sensitivity.py --input sensitivity_results.json
"""
import os
import sys
import json
import argparse

# ── path bootstrap (must precede package imports) ──────────────────
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from experiments._common import add_common_args, config_from_args  # noqa: E402
from engine import run_experiment                                  # noqa: E402


# parameter -> (Config field, default grid, axis label, column label)
PARAM_SPEC = {
    'K': ('n_modes',       [4, 8, 16, 32],     'K',             'n_modes  K'),
    'D': ('d_model',       [32, 64, 128, 256], 'd_model',       'd_model'),
    'E': ('dmd_embed_len', [4, 8, 16, 32],     'dmd_embed_len', 'dmd_embed_len'),
}


def parse_args():
    p = argparse.ArgumentParser(
        description="PhyTM hyperparameter sensitivity sweep",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument('--datasets', default="ETTh1,ETTh2,ETTm1,ETTm2",
                   help='comma-separated dataset names')
    p.add_argument('--pred_len', type=int, default=96,
                   help='single prediction horizon for the sweep')
    p.add_argument('--params', default="K,D,E",
                   help='comma-separated parameters to sweep (subset of K,D,E)')
    p.add_argument('--K_grid', default=None, help='override grid for K')
    p.add_argument('--D_grid', default=None, help='override grid for D')
    p.add_argument('--E_grid', default=None, help='override grid for E')
    add_common_args(p)
    p.add_argument('--output_json', default='sensitivity_results.json')
    p.add_argument('--resume', action='store_true',
                   help='load existing output JSON and skip already-completed entries; '
                        'use with --params E to re-run only the failed/missing param '
                        'without losing K/D data already in the JSON')
    p.add_argument('--dry_run', action='store_true',
                   help='list the planned runs and exit')
    return p.parse_args()


def resolve_grids(args, params):
    grids = {}
    for pk in params:
        override = getattr(args, f"{pk}_grid")
        if override:
            grids[pk] = [int(v) for v in override.split(',') if v.strip()]
        else:
            grids[pk] = list(PARAM_SPEC[pk][1])
    return grids


def main():
    args = parse_args()
    datasets = [d.strip() for d in args.datasets.split(',') if d.strip()]
    params   = [p.strip() for p in args.params.split(',') if p.strip()]
    for pk in params:
        if pk not in PARAM_SPEC:
            raise SystemExit(f"unknown param {pk!r}; choose from {list(PARAM_SPEC)}")
    grids = resolve_grids(args, params)

    plan = [(pk, val, ds) for pk in params for val in grids[pk] for ds in datasets]
    total = len(plan)

    if args.dry_run:
        print(f"Planned {total} run(s) at pred_len={args.pred_len}:")
        for i, (pk, val, ds) in enumerate(plan, 1):
            field = PARAM_SPEC[pk][0]
            print(f"  [{i}/{total}] {pk}({field}={val})  {ds}")
        return

    # build output skeleton; if --resume, start from the existing JSON so that
    # params not in --params (e.g. K and D when re-running only E) are preserved.
    if args.resume and os.path.exists(args.output_json):
        with open(args.output_json, encoding='utf-8') as f:
            out = json.load(f)
        print(f"[resume] loaded existing results from {args.output_json}")
        # ensure entries exist for every requested param / dataset / grid value
        for pk in params:
            field, _, xlabel, col_label = PARAM_SPEC[pk]
            if pk not in out["params"]:
                out["params"][pk] = dict(
                    field=field, xlabel=xlabel, col_label=col_label,
                    xlabels=[str(v) for v in grids[pk]],
                    MSE={ds: [None] * len(grids[pk]) for ds in datasets},
                    MAE={ds: [None] * len(grids[pk]) for ds in datasets},
                    opt={},
                )
            else:
                for ds in datasets:
                    if ds not in out["params"][pk]["MSE"]:
                        out["params"][pk]["MSE"][ds] = [None] * len(grids[pk])
                        out["params"][pk]["MAE"][ds] = [None] * len(grids[pk])
    else:
        out = {"pred_len": args.pred_len, "params": {}}
        for pk in params:
            field, _, xlabel, col_label = PARAM_SPEC[pk]
            out["params"][pk] = dict(
                field=field, xlabel=xlabel, col_label=col_label,
                xlabels=[str(v) for v in grids[pk]],
                MSE={ds: [None] * len(grids[pk]) for ds in datasets},
                MAE={ds: [None] * len(grids[pk]) for ds in datasets},
                opt={},
            )

    i = 0
    for pk in params:
        field = PARAM_SPEC[pk][0]
        grid = grids[pk]
        for vi, val in enumerate(grid):
            for ds in datasets:
                i += 1
                # --resume: skip entries that already have a valid result
                if out["params"][pk]["MSE"][ds][vi] is not None:
                    existing = out["params"][pk]["MSE"][ds][vi]
                    print(f"[{i}/{total}] {pk}={val} {ds}  "
                          f"[resume] already done MSE={existing:.4f}, skip")
                    continue
                print(f"\n[{i}/{total}] {pk}({field}={val})  {ds}  "
                      f"pred_len={args.pred_len}")
                cfg = config_from_args(
                    args, ds, args.pred_len, **{field: val},
                    save_dir=os.path.join(args.save_dir,
                                          f"sens_{pk}{val}"))
                try:
                    res = run_experiment(cfg)
                    out["params"][pk]["MSE"][ds][vi] = round(res["test_MSE"], 6)
                    out["params"][pk]["MAE"][ds][vi] = round(res["test_MAE"], 6)
                except Exception as e:
                    print(f"  [FAILED] {type(e).__name__}: {e}")
                # persist progressively (Ctrl-C safe)
                with open(args.output_json, 'w', encoding='utf-8') as f:
                    json.dump(out, f, indent=2, ensure_ascii=False)

        # per-dataset optimum index = argmin MSE over the grid (finite values)
        for ds in datasets:
            vals = out["params"][pk]["MSE"][ds]
            finite = [(v, j) for j, v in enumerate(vals) if v is not None]
            if finite:
                out["params"][pk]["opt"][ds] = min(finite)[1]
    with open(args.output_json, 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=2, ensure_ascii=False)

    print(f"\nsensitivity results written to {args.output_json}")
    print(f"plot with: python experiments/plot_sensitivity.py "
          f"--input {args.output_json}")


if __name__ == '__main__':
    main()
