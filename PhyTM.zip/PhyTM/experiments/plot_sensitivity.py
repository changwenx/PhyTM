# -*- coding: utf-8 -*-
"""
PhyTM sensitivity figure
========================
Renders the hyperparameter sensitivity panel (2 rows x 3 columns: MSE/MAE over
K / d_model / dmd_embed_len). Each curve is expressed as the relative change (%)
from that dataset's best setting, so the figures share a common y-axis meaning.

Data source
-----------
- ``--input results.json`` : use measured results from ``run_sensitivity.py``.
- no ``--input``           : auto-load ``sensitivity_results.json`` from the
                             current directory if present (your measured run).
- ``--demo``               : use the built-in placeholder numbers ONLY for a
                             quick layout preview. The figure is stamped with a
                             "DEMO DATA" watermark so it can never be mistaken
                             for measured results.

If no measured JSON is found and ``--demo`` is not given, the script stops with
a message telling you to run the sweep first (it does not silently plot
placeholder numbers).

Usage
-----
    # 1) run the sweep on your data (paths default to /home/zc/cwx/data)
    python experiments/run_sensitivity.py
    # 2) plot the measured results (auto-detected)
    python experiments/plot_sensitivity.py
    # or preview the layout with placeholder numbers
    python experiments/plot_sensitivity.py --demo
"""
import os
import json
import argparse

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.ticker as mticker
from matplotlib.lines import Line2D


# ── built-in placeholder numbers (NOT measured results) ───────────
# These are illustrative values used ONLY with --demo to preview the figure
# layout. Replace them with your own run via run_sensitivity.py. Any figure
# drawn from these is watermarked "DEMO DATA".
DEMO_DATA = {
    "pred_len": 96,
    "params": {
        "K": {
            "xlabel": "K", "col_label": "n_modes  K", "xlabels": ["4", "8", "16", "32"],
            "MSE": {"ETTh1": [0.3720, 0.3690, 0.3750, 0.3725],
                    "ETTh2": [0.2961, 0.2922, 0.2974, 0.2957],
                    "ETTm1": [0.3167, 0.3170, 0.3193, 0.3156],
                    "ETTm2": [0.1745, 0.1719, 0.1745, 0.1749]},
            "MAE": {"ETTh1": [0.3942, 0.3901, 0.3951, 0.3947],
                    "ETTh2": [0.3409, 0.3311, 0.3429, 0.3407],
                    "ETTm1": [0.3505, 0.3512, 0.3526, 0.3508],
                    "ETTm2": [0.2511, 0.2501, 0.2507, 0.2527]},
            "opt": {"ETTh1": 1, "ETTh2": 1, "ETTm1": 3, "ETTm2": 0},
        },
        "D": {
            "xlabel": "d_model", "col_label": "d_model", "xlabels": ["32", "64", "128", "256"],
            "MSE": {"ETTh1": [0.4732, 0.3849, 0.3680, 0.3675],
                    "ETTh2": [0.3115, 0.2922, 0.2922, 0.2978],
                    "ETTm1": [0.3757, 0.3277, 0.3170, 0.3171],
                    "ETTm2": [0.1801, 0.1766, 0.1718, 0.1778]},
            "MAE": {"ETTh1": [0.4528, 0.4004, 0.3900, 0.3941],
                    "ETTh2": [0.3593, 0.3400, 0.3331, 0.3417],
                    "ETTm1": [0.3934, 0.3599, 0.3512, 0.3499],
                    "ETTm2": [0.2602, 0.2564, 0.2491, 0.2529]},
            "opt": {"ETTh1": 2, "ETTh2": 2, "ETTm1": 3, "ETTm2": 2},
        },
        "E": {
            "xlabel": "dmd_embed_len", "col_label": "dmd_embed_len",
            "xlabels": ["4", "8", "16", "32"],
            "MSE": {"ETTh1": [0.3711, 0.3681, 0.3708, 0.3712],
                    "ETTh2": [0.2928, 0.2922, 0.2926, 0.2923],
                    "ETTm1": [0.3180, 0.3167, 0.3151, 0.3166],
                    "ETTm2": [0.1759, 0.1718, 0.1753, 0.1753]},
            "MAE": {"ETTh1": [0.3921, 0.3901, 0.3919, 0.3921],
                    "ETTh2": [0.3384, 0.3381, 0.3315, 0.3389],
                    "ETTm1": [0.3522, 0.3515, 0.3495, 0.3504],
                    "ETTm2": [0.2519, 0.2511, 0.2523, 0.2524]},
            "opt": {"ETTh1": 1, "ETTh2": 1, "ETTm1": 2, "ETTm2": 1},
        },
    },
}

C  = {'ETTh1': '#4C72B0', 'ETTh2': '#55A868', 'ETTm1': '#C44E52', 'ETTm2': '#DD8452'}
MK = {'ETTh1': 'o', 'ETTh2': 's', 'ETTm1': '^', 'ETTm2': 'D'}
LW, MS = 1.5, 7
METRICS = ['MSE', 'MAE']
PANEL = [['(a)', '(b)', '(c)'], ['(d)', '(e)', '(f)']]

_FALLBACK_COLORS = ['#8172B2', '#937860', '#DA8BC3', '#64B5CD', '#CCB974', '#B07AA1']
_FALLBACK_MARKERS = ['v', 'p', 'X', '*', 'h', 'P']


def set_style():
    plt.rcParams.update({
        'font.family': 'serif', 'font.size': 7,
        'axes.titlesize': 9, 'axes.labelsize': 8,
        'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 7,
        'axes.linewidth': 0.7,
        'xtick.direction': 'out', 'ytick.direction': 'out',
        'xtick.major.size': 3.0, 'ytick.major.size': 3.0,
        'xtick.major.width': 0.7, 'ytick.major.width': 0.7,
        'axes.spines.top': False, 'axes.spines.right': False,
        'figure.dpi': 150, 'savefig.dpi': 300,
        'savefig.bbox': 'tight', 'savefig.pad_inches': 0.02,
        'pdf.fonttype': 42, 'figure.facecolor': 'white', 'axes.facecolor': 'white',
    })


def _ensure_opt(pdata):
    """Fill in opt (argmin MSE) if a sweep JSON omitted it."""
    for pk, cfg in pdata.items():
        if cfg.get('opt'):
            continue
        cfg['opt'] = {}
        for ds, vals in cfg['MSE'].items():
            finite = [(v, j) for j, v in enumerate(vals) if v is not None]
            cfg['opt'][ds] = min(finite)[1] if finite else 0


def _datasets_in(pdata):
    """Stable ordering: known ETT datasets first, then any extras."""
    seen, order = set(), []
    for pk in pdata:
        for ds in pdata[pk]['MSE']:
            if ds not in seen:
                seen.add(ds); order.append(ds)
    known = [d for d in ['ETTh1', 'ETTh2', 'ETTm1', 'ETTm2'] if d in seen]
    extra = [d for d in order if d not in known]
    return known + extra


def _color(ds, i):
    return C.get(ds, _FALLBACK_COLORS[i % len(_FALLBACK_COLORS)])


def _marker(ds, i):
    return MK.get(ds, _FALLBACK_MARKERS[i % len(_FALLBACK_MARKERS)])


def fmt_pct(v, _):
    if abs(v) >= 10:
        return f'{v:+.0f}%'
    elif abs(v) >= 1:
        return f'{v:+.1f}%'
    return f'{v:+.2f}%'


def plot(payload, out_dir, stem='fig_sensitivity', demo=False):
    pdata = payload['params']
    pred_len = payload.get('pred_len', 96)
    _ensure_opt(pdata)
    params = list(pdata.keys())
    datasets = _datasets_in(pdata)
    ncol = len(params)

    fig = plt.figure(figsize=(1.95 * ncol, 3.6))
    GS = gridspec.GridSpec(2, ncol, figure=fig,
                           left=0.07, right=0.99, top=0.82, bottom=0.12,
                           hspace=0.65, wspace=0.26)

    for ri, metric in enumerate(METRICS):
        for ci, pk in enumerate(params):
            ax = fig.add_subplot(GS[ri, ci])
            cfg = pdata[pk]
            xlabels = cfg['xlabels']
            n = len(xlabels)
            xpos = list(range(n))
            ydict = cfg[metric]
            opt = cfg['opt']

            pct_all = []
            for di, ds in enumerate(datasets):
                if ds not in ydict:
                    continue
                y = np.array([np.nan if v is None else v for v in ydict[ds]],
                             dtype=float)
                base = y[opt.get(ds, 0)]
                if not np.isfinite(base):   # null / failed run at opt index
                    continue
                pct = (y - base) / base * 100.0
                pct_all.append(pct[~np.isnan(pct)])
                ax.plot(xpos, pct, color=_color(ds, di), marker=_marker(ds, di),
                        lw=LW, ms=MS, mfc=_color(ds, di), mec='white', mew=0.8,
                        label=ds, zorder=3)

            # modal optimum band (most common best index across datasets)
            opt_counts = {}
            for ds in datasets:
                if ds in opt:
                    opt_counts[opt[ds]] = opt_counts.get(opt[ds], 0) + 1
            if opt_counts:
                modal_opt = max(opt_counts, key=opt_counts.get)
                ax.axvspan(modal_opt - 0.38, modal_opt + 0.38,
                           color='#9DC3E6', alpha=0.35, zorder=0, lw=0)
                ax.axvline(modal_opt, color='#2166AC', lw=1.0,
                           ls=(0, (4, 3)), zorder=2, alpha=0.9)
            ax.axhline(0, color='#AAAAAA', lw=0.6, ls='--', zorder=1)

            for sp in ('left', 'bottom'):
                ax.spines[sp].set_linewidth(0.7)
                ax.spines[sp].set_color('#333333')
            ax.tick_params(which='both', direction='out', top=False, right=False,
                           labelsize=7, length=3.0, width=0.7, pad=2)

            ax.set_xlim(-0.3, n - 0.7)
            ax.set_xticks(xpos)
            ax.set_xticklabels(xlabels, fontsize=7)
            ax.set_xlabel(cfg['xlabel'], fontsize=8, style='italic', labelpad=2)

            if pct_all:
                allp = np.concatenate(pct_all)
                if allp.size > 0:               # skip if every value was NaN
                    span = max(float(abs(allp).max()), 0.15)
                    pad = span * 0.18
                    ax.set_ylim(float(allp.min()) - pad, float(allp.max()) + pad)
            ax.yaxis.set_major_formatter(mticker.FuncFormatter(fmt_pct))
            ax.yaxis.set_major_locator(mticker.MaxNLocator(4))
            ax.set_title(f'{PANEL[ri][ci]}  {metric}',
                         fontsize=9, fontweight='bold', pad=3, loc='left')

    for ri2 in range(2):
        ax0 = fig.axes[ri2 * ncol]
        ax0.text(-0.18, 1.0, r'$\Delta$(%)', transform=ax0.transAxes,
                 va='bottom', ha='left', fontsize=7, color='#333333')

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for ci, pk in enumerate(params):
        ax_top = fig.axes[ci]
        bb = ax_top.get_tightbbox(renderer).transformed(fig.transFigure.inverted())
        gs_pos = GS[0, ci].get_position(fig)
        fig.text(gs_pos.x0, bb.y1 + 0.006, pdata[pk]['col_label'],
                 va='bottom', ha='left', fontsize=7, style='italic', color='#2166AC')

    handles = [Line2D([0], [0], color=_color(ds, di), marker=_marker(ds, di),
                      lw=LW, ms=MS, mfc=_color(ds, di), mec='white', mew=0.8, label=ds)
               for di, ds in enumerate(datasets)]
    leg = fig.legend(handles=handles, loc='upper center', ncol=len(datasets),
                     fontsize=7, frameon=True, framealpha=0.97, edgecolor='#CCCCCC',
                     fancybox=False, bbox_to_anchor=(0.55, 0.995),
                     handlelength=1.6, handletextpad=0.4, columnspacing=0.8,
                     borderpad=0.4, title='Datasets', title_fontsize=7.5)
    leg.get_title().set_fontweight('bold')
    fig.suptitle(f'Hyperparameter Sensitivity Analysis  (pred_len = {pred_len})',
                 fontsize=8, fontweight='bold', y=1.04)

    if demo:
        # unmistakable watermark so placeholder figures can never pass as real
        fig.text(0.5, 0.5, "DEMO DATA", transform=fig.transFigure,
                 fontsize=52, color="#C0392B", alpha=0.16, rotation=28,
                 ha="center", va="center", fontweight="bold", zorder=1000)

    os.makedirs(out_dir, exist_ok=True)
    saved = []
    for ext in ('png', 'pdf'):
        out = os.path.join(out_dir, f'{stem}.{ext}')
        fig.savefig(out)
        saved.append(out)
    plt.close()
    return saved


DEFAULT_RESULTS = 'sensitivity_results.json'


def main():
    p = argparse.ArgumentParser(
        description="render the PhyTM sensitivity figure from measured results")
    p.add_argument('--input', default=None,
                   help=f'measured results JSON from run_sensitivity.py '
                        f'(default: auto-detect ./{DEFAULT_RESULTS})')
    p.add_argument('--demo', action='store_true',
                   help='use built-in placeholder numbers for a layout preview '
                        '(figure is watermarked "DEMO DATA")')
    p.add_argument('--out_dir', default='.', help='directory for the output figures')
    p.add_argument('--stem', default='fig_sensitivity', help='output file stem')
    args = p.parse_args()

    demo = False
    if args.input:                                   # explicit measured file
        if not os.path.exists(args.input):
            raise SystemExit(f"--input file not found: {args.input}")
        with open(args.input, encoding='utf-8') as f:
            payload = json.load(f)
        print(f"loaded measured results from {args.input}")
    elif args.demo:                                  # explicit preview request
        payload = DEMO_DATA
        demo = True
        print("WARNING: using built-in DEMO placeholder numbers -- these are "
              "NOT measured results.\n         Run experiments/run_sensitivity.py "
              "to produce real numbers.")
    elif os.path.exists(DEFAULT_RESULTS):            # auto-detect measured file
        with open(DEFAULT_RESULTS, encoding='utf-8') as f:
            payload = json.load(f)
        print(f"auto-loaded measured results from ./{DEFAULT_RESULTS}")
    else:                                            # refuse to fake it
        raise SystemExit(
            f"no measured results found (looked for ./{DEFAULT_RESULTS}).\n"
            f"Run the sweep first, e.g.:\n"
            f"    python experiments/run_sensitivity.py\n"
            f"then re-run this script. To preview the layout with placeholder "
            f"numbers, pass --demo.")

    set_style()
    saved = plot(payload, args.out_dir, args.stem, demo=demo)
    for s in saved:
        print("saved", s)


if __name__ == '__main__':
    main()
