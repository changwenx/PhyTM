"""
Shared utilities for the PhyTM experiment scripts
=================================================
Common argparse options and a Config builder, so the ablation and sensitivity
runners stay small. Importing this module assumes the package root is already
on ``sys.path`` (each runnable script does that in a two-line bootstrap before
importing anything from the package).
"""
import os
import sys


def bootstrap_path():
    """Put the package root (the parent of experiments/) on sys.path so that
    ``from config import ...`` / ``from engine import ...`` work whether the
    script is run as ``python experiments/x.py`` or ``python -m experiments.x``."""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if root not in sys.path:
        sys.path.insert(0, root)
    return root


bootstrap_path()

from config import Config  # noqa: E402  (after bootstrap)


def add_common_args(parser):
    """Add the data / model / training options shared by the experiment runners."""
    # ── data ──────────────────────────────────────────────────────
    parser.add_argument('--data_root', default=Config.data_root,
                        help='directory holding the dataset CSV files')
    parser.add_argument('--seq_len', type=int, default=Config.seq_len)
    parser.add_argument('--features', default=Config.features, choices=['M'])

    # ── model ─────────────────────────────────────────────────────
    parser.add_argument('--d_model', type=int, default=Config.d_model)
    parser.add_argument('--d_state', type=int, default=Config.d_state)
    parser.add_argument('--n_text_layers', type=int, default=Config.n_text_layers)
    parser.add_argument('--n_image_layers', type=int, default=Config.n_image_layers)
    parser.add_argument('--n_cross_layers', type=int, default=Config.n_cross_layers)
    parser.add_argument('--n_gtm_layers', type=int, default=Config.n_gtm_layers)
    parser.add_argument('--n_heads', type=int, default=Config.n_heads)
    parser.add_argument('--patch_len', type=int, default=Config.patch_len)
    parser.add_argument('--patch_stride', type=int, default=Config.patch_stride)
    parser.add_argument('--img_patch', type=int, default=Config.img_patch)

    # ── DMD physics extraction ────────────────────────────────────
    parser.add_argument('--n_modes', type=int, default=Config.n_modes)
    parser.add_argument('--dmd_embed_len', type=int, default=Config.dmd_embed_len)
    parser.add_argument('--dmd_rank', type=int, default=Config.dmd_rank)
    parser.add_argument('--dmd_delta_t', type=float, default=Config.dmd_delta_t)
    parser.add_argument('--lambda_phys', type=float, default=Config.lambda_phys)

    # ── textual path / GPT-2 ──────────────────────────────────────
    parser.add_argument('--gpt2_path', default=Config.gpt2_path)
    parser.add_argument('--max_prompt_len', type=int, default=Config.max_prompt_len)
    parser.add_argument('--no_gpt2', action='store_true',
                        help='disable the GPT-2 dual stream')

    # ── training ──────────────────────────────────────────────────
    parser.add_argument('--batch_size', type=int, default=Config.batch_size)
    parser.add_argument('--lr', type=float, default=Config.lr)
    parser.add_argument('--weight_decay', type=float, default=Config.weight_decay)
    parser.add_argument('--epochs', type=int, default=Config.epochs)
    parser.add_argument('--patience', type=int, default=Config.patience)
    parser.add_argument('--min_epochs', type=int, default=Config.min_epochs)
    parser.add_argument('--grad_clip', type=float, default=Config.grad_clip)
    parser.add_argument('--num_workers', type=int, default=Config.num_workers)
    parser.add_argument('--device', default=Config.device)
    parser.add_argument('--seed', type=int, default=Config.seed)
    parser.add_argument('--save_dir', default=Config.save_dir)
    parser.add_argument('--warmup_epochs', type=int, default=Config.warmup_epochs)
    parser.add_argument('--no_lr_scale', action='store_true',
                        help='disable the sqrt(96/seq_len) LR scaling')
    parser.add_argument('--verbose', action='store_true',
                        help='print per-run diagnostics')
    return parser


def config_from_args(args, dataset: str, pred_len: int, **overrides) -> Config:
    """Build a Config from parsed common args for one (dataset, pred_len)."""
    cfg = Config(
        data_root=args.data_root, dataset=dataset, features=args.features,
        seq_len=args.seq_len, pred_len=pred_len,
        patch_len=args.patch_len, patch_stride=args.patch_stride,
        img_patch=args.img_patch, img_size=None,
        d_model=args.d_model, d_state=args.d_state,
        n_text_layers=args.n_text_layers, n_image_layers=args.n_image_layers,
        n_cross_layers=args.n_cross_layers, n_gtm_layers=args.n_gtm_layers,
        n_heads=args.n_heads,
        n_modes=args.n_modes, dmd_embed_len=args.dmd_embed_len,
        dmd_rank=args.dmd_rank, dmd_delta_t=args.dmd_delta_t,
        lambda_phys=args.lambda_phys,
        gpt2_path=args.gpt2_path, max_prompt_len=args.max_prompt_len,
        use_gpt2=(not args.no_gpt2),
        batch_size=args.batch_size, lr=args.lr, weight_decay=args.weight_decay,
        epochs=args.epochs, patience=args.patience, min_epochs=args.min_epochs,
        grad_clip=args.grad_clip, num_workers=args.num_workers,
        device=args.device, seed=args.seed, save_dir=args.save_dir,
        warmup_epochs=args.warmup_epochs, no_lr_scale=args.no_lr_scale,
        verbose=args.verbose,
    )
    return cfg.copy(**overrides) if overrides else cfg
