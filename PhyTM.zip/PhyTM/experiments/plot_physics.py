# -*- coding: utf-8 -*-
"""
PhyTM physics-spectrum visualization
====================================
Extracts the learned damped-oscillator spectrum from trained checkpoints and
draws four conference-style figures:

  1) fig_pole_spectrum  continuous-time poles (s-plane) + discrete-time
                        eigenvalues (z-plane)
  2) fig_pole_facets    per-dataset eigenvalue maps (one z-plane panel each)
  3) fig_basis_all      the learned damped-oscillator bases
                        exp(alpha_k t) cos(omega_k t)
  4) fig_heatmaps       (a) decay-rate alpha heatmap  (b) angular-frequency
                        omega heatmap

Physics background
------------------
The phy_extractor models a series as a sum of K damped oscillators; mode k has
basis x_k(t) = beta_k * exp(alpha_k t) * cos(omega_k t), with
  alpha_k = base_alpha_k + delta_alpha_k   (decay rate, negative => stable)
  omega_k = base_omega_k + delta_omega_k   (angular frequency)
The discrete-time eigenvalue is z_k = exp((alpha_k + i omega_k) dt); |z_k| < 1
indicates stability.

Checkpoints are read with ``torch.load`` (only tensors are needed, so the model
class is not imported). Point ``--ckpt_dir`` at a directory of ``*.pt`` files
named ``<dataset>_M_sl<sl>_pl<pl>.pt`` (the layout produced by run_benchmark.py).

Usage
-----
    python experiments/plot_physics.py --ckpt_dir checkpoints_benchmark
"""
import os
import re
import glob
import argparse

import numpy as np
import torch
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.colors import TwoSlopeNorm, Normalize


# known datasets get fixed display names / colours / markers; anything else
# falls back to a rotating palette so custom datasets still plot.
DISPLAY = {
    "ETTh1": "ETTh1", "ETTh2": "ETTh2", "ETTm1": "ETTm1", "ETTm2": "ETTm2",
    "electricity": "Electricity", "exchange_rate": "Exchange",
    "traffic": "Traffic", "weather": "Weather",
}
KNOWN_ORDER = ["ETTh1", "ETTh2", "ETTm1", "ETTm2",
               "electricity", "exchange_rate", "traffic", "weather"]
PALETTE = {
    "ETTh1": "#4C72B0", "ETTh2": "#55A868", "ETTm1": "#C44E52", "ETTm2": "#DD8452",
    "electricity": "#8172B2", "exchange_rate": "#937860",
    "traffic": "#DA8BC3", "weather": "#64B5CD",
}
MARKERS = {
    "ETTh1": "o", "ETTh2": "s", "ETTm1": "^", "ETTm2": "D",
    "electricity": "v", "exchange_rate": "p", "traffic": "X", "weather": "*",
}
_FB_COLORS = ["#B07AA1", "#76B7B2", "#EDC948", "#9C755F", "#BAB0AC", "#FF9DA7"]
_FB_MARKERS = ["o", "s", "^", "D", "v", "p", "X", "*"]
FRAME = "#444444"


def display(ds):
    return DISPLAY.get(ds, ds)


def palette(ds, i):
    return PALETTE.get(ds, _FB_COLORS[i % len(_FB_COLORS)])


def marker(ds, i):
    return MARKERS.get(ds, _FB_MARKERS[i % len(_FB_MARKERS)])


def row_order(ds_mean):
    known = [d for d in KNOWN_ORDER if d in ds_mean]
    extra = [d for d in ds_mean if d not in KNOWN_ORDER]
    return known + extra


# ============================================================================
#   collect physics parameters from checkpoints (avg per dataset over horizons)
# ============================================================================
_PAT = re.compile(r"(.+)_M_sl(\d+)_pl(\d+)\.pt$")


def collect(ckpt_dir):
    files = sorted(glob.glob(os.path.join(ckpt_dir, "*.pt")))
    if not files:
        return {}
    bucket = {}
    for f in files:
        m = _PAT.match(os.path.basename(f))
        if not m:
            continue
        ds = m.group(1)
        sd = torch.load(f, map_location="cpu")
        try:
            g = lambda k: np.asarray(sd[k].detach().cpu().numpy(), dtype=np.float64)
            alpha = g("phy_extractor.base_alpha") + g("phy_extractor.delta_alpha")
            omega = g("phy_extractor.base_omega") + g("phy_extractor.delta_omega")
            beta = g("text_encoder.beta")
        except KeyError:
            print(f"  [skip] {os.path.basename(f)}: missing physics tensors")
            continue
        bucket.setdefault(ds, []).append((alpha, omega, beta))

    ds_mean = {}
    for ds, lst in bucket.items():
        # keep only entries matching the modal mode-count (consistent K)
        kref = len(lst[0][0])
        good = [x for x in lst if len(x[0]) == kref]
        if len(good) < len(lst):
            print(f"  [warn] {ds}: dropped {len(lst) - len(good)} ckpt(s) "
                  f"with a different n_modes")
        A = np.mean([x[0] for x in good], axis=0)
        W = np.mean([x[1] for x in good], axis=0)
        B = np.mean([x[2] for x in good], axis=0)
        order = np.argsort(-A)   # slowest-decaying mode first
        ds_mean[ds] = dict(alpha=A[order], omega=W[order], beta=B[order])
    return ds_mean


# ============================================================================
#   styling
# ============================================================================
def set_style():
    mpl.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif", "Times"],
        "mathtext.fontset": "dejavuserif",
        "font.size": 7, "axes.titlesize": 9, "axes.labelsize": 8,
        "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
        "axes.linewidth": 0.7,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3.0, "ytick.major.size": 3.0,
        "xtick.major.width": 0.7, "ytick.major.width": 0.7,
        "axes.spines.top": False, "axes.spines.right": False,
        "legend.frameon": True, "legend.framealpha": 0.95,
        "legend.edgecolor": "#CCCCCC", "legend.fancybox": False,
        "legend.handletextpad": 0.4, "legend.columnspacing": 0.8,
        "legend.borderpad": 0.4,
        "figure.dpi": 150, "savefig.dpi": 300,
        "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "figure.facecolor": "white", "axes.facecolor": "white",
    })


def _beta_range(ds_mean):
    allb = np.concatenate([np.abs(ds_mean[d]["beta"]) for d in ds_mean])
    bmin, bmax = float(allb.min()), float(allb.max())
    if bmax - bmin < 1e-9:
        bmax = bmin + 1.0
    return bmin, bmax


def _size_fn(bmin, bmax, lo=12, hi=140):
    def f(b):
        b = np.asarray(b, dtype=float)
        frac = np.clip((b - bmin) / (bmax - bmin), 0.0, 1.0)
        return lo + frac * (hi - lo)
    return f


def _legend_betas(bmin, bmax):
    """Three |beta| reference values spanning the interior of the observed range
    (for the size legend). De-duplicated in case the range is narrow."""
    span = bmax - bmin
    vals = sorted(set(round(bmin + f * span, 2) for f in (0.15, 0.5, 0.9)))
    return vals if vals else [round(bmin, 2)]


def _frame(ax):
    for s in ax.spines.values():
        s.set_visible(True); s.set_color(FRAME); s.set_linewidth(0.7)
    ax.tick_params(direction="in", length=2.5, width=0.7, pad=2.5,
                   top=True, right=True)


# ============================================================================
#   figure 1: pole spectrum (s-plane) + eigenvalues (z-plane)
# ============================================================================
def fig_pole_spectrum(ds_mean, out_dir, size, legend_betas):
    import matplotlib.ticker as mticker
    from matplotlib.lines import Line2D

    mpl.rcParams.update({"font.size": 8, "axes.titlesize": 9, "axes.labelsize": 8,
                         "xtick.labelsize": 7, "ytick.labelsize": 7,
                         "legend.fontsize": 8})
    rows = row_order(ds_mean)
    fig, (axp, axz) = plt.subplots(1, 2, figsize=(6.6, 3.0))
    fig.subplots_adjust(left=0.07, right=0.985, top=0.88, bottom=0.15, wspace=0.20)

    allA = np.concatenate([ds_mean[d]["alpha"] for d in rows])
    allW = np.concatenate([ds_mean[d]["omega"] for d in rows])

    # (a) s-plane
    for di, ds in enumerate(rows):
        axp.scatter(ds_mean[ds]["omega"], ds_mean[ds]["alpha"],
                    s=size(np.abs(ds_mean[ds]["beta"])),
                    c=palette(ds, di), marker=marker(ds, di),
                    edgecolors="white", linewidths=0.6, alpha=0.9,
                    label=display(ds), zorder=4)
    _frame(axp)
    wpad = (allW.max() - allW.min()) * 0.07 if allW.max() > allW.min() else 0.1
    aspan = allA.max() - allA.min() if allA.max() > allA.min() else 1.0
    axp.set_xlim(allW.min() - wpad, allW.max() + wpad)
    axp.set_ylim(allA.min() - aspan * 0.10, aspan * 0.10)
    axp.xaxis.set_major_locator(mticker.MaxNLocator(5))
    axp.yaxis.set_major_locator(mticker.MaxNLocator(5))
    axp.set_xlabel(r"angular frequency  $\omega_k$", labelpad=2)
    axp.set_ylabel(r"decay rate  $\alpha_k$", labelpad=2)
    axp.set_title(r"(a)  Continuous-time poles ($s$-plane)", loc="left", pad=4)
    axp.set_box_aspect(1.0)

    size_vals = legend_betas
    size_handles = [Line2D([0], [0], marker="o", color="none",
                           markerfacecolor="#AAAAAA", markeredgecolor="white",
                           markeredgewidth=0.5, markersize=np.sqrt(size(v)),
                           label=f"{v:.2f}") for v in size_vals]
    leg2 = axp.legend(handles=size_handles, title=r"$|\beta_k|$",
                      loc="lower right", fontsize=6.5, title_fontsize=7,
                      handletextpad=0.5, labelspacing=0.85, borderpad=0.55,
                      frameon=True, framealpha=0.95, edgecolor="#DDDDDD")
    leg2.get_frame().set_linewidth(0.5)

    # (b) z-plane
    th = np.linspace(0, 2 * np.pi, 400)
    axz.plot(np.cos(th), np.sin(th), color="#888888", lw=0.8, zorder=2)
    axz.plot([-1.12, 1.12], [0, 0], color="#E2E2E2", lw=0.5, zorder=1)
    axz.plot([0, 0], [-1.12, 1.12], color="#E2E2E2", lw=0.5, zorder=1)
    for di, ds in enumerate(rows):
        a = ds_mean[ds]["alpha"]; w = ds_mean[ds]["omega"]; r = np.exp(a)
        axz.scatter(r * np.cos(w), r * np.sin(w),
                    s=size(np.abs(ds_mean[ds]["beta"])),
                    c=palette(ds, di), marker=marker(ds, di),
                    edgecolors="white", linewidths=0.6, alpha=0.9, zorder=4)
    _frame(axz)
    axz.set_aspect("equal")
    axz.set_xlim(-1.15, 1.15); axz.set_ylim(-1.15, 1.15)
    axz.set_xticks([-1, -0.5, 0, 0.5, 1]); axz.set_yticks([-1, -0.5, 0, 0.5, 1])
    axz.set_xlabel(r"$\mathrm{Re}\,(z_k)$", labelpad=2)
    axz.set_ylabel(r"$\mathrm{Im}\,(z_k)$", labelpad=2)
    axz.set_title(r"(b)  Discrete-time eigenvalues ($z$-plane)", loc="left", pad=4)
    axz.text(0.97, 0.97, r"$|z|=1$", transform=axz.transAxes,
             fontsize=7, color="#666666", ha="right", va="top")
    axz.set_box_aspect(1.0)

    ds_handles = [Line2D([0], [0], marker=marker(d, di), color="none",
                         markerfacecolor=palette(d, di), markeredgecolor="white",
                         markeredgewidth=0.5, markersize=6, label=display(d))
                  for di, d in enumerate(rows)]
    fig.legend(handles=ds_handles, loc="upper center", ncol=min(8, len(rows)),
               bbox_to_anchor=(0.5, 1.04), frameon=False, handletextpad=0.2,
               columnspacing=0.7, handlelength=1.0, fontsize=7.5)

    saved = [os.path.join(out_dir, f"fig_pole_spectrum.{e}") for e in ("pdf", "png")]
    for s in saved:
        fig.savefig(s)
    plt.close()
    mpl.rcParams.update({"font.size": 7, "axes.titlesize": 9, "axes.labelsize": 8,
                         "xtick.labelsize": 7, "ytick.labelsize": 7,
                         "legend.fontsize": 7})
    return saved


# ============================================================================
#   figure 1b: per-dataset z-plane facets
# ============================================================================
def fig_pole_facets(ds_mean, out_dir, size, legend_betas):
    from matplotlib.patches import Circle
    from matplotlib.lines import Line2D

    rows = row_order(ds_mean)
    ncols = min(4, max(1, len(rows)))
    nrows = int(np.ceil(len(rows) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(1.8 * ncols, 2.0 * nrows),
                             squeeze=False)
    fig.subplots_adjust(left=0.015, right=0.985, top=0.86, bottom=0.075,
                        hspace=0.28, wspace=0.12)
    th = np.linspace(0, 2 * np.pi, 300)

    flat = axes.flat
    for idx, ds in enumerate(rows):
        ax = flat[idx]
        a = np.array(ds_mean[ds]["alpha"]); w = np.array(ds_mean[ds]["omega"])
        b = np.abs(ds_mean[ds]["beta"]); r = np.exp(a)
        ax.fill(np.cos(th), np.sin(th), color=palette(ds, idx), alpha=0.05, zorder=0)
        ax.add_patch(Circle((0, 0), 0.5, fill=False, lw=0.4, ls=(0, (3, 3)),
                            ec="#D5D5D5", zorder=1))
        ax.plot(np.cos(th), np.sin(th), color="#666666", lw=0.9, zorder=2)
        ax.axhline(0, color="#E0E0E0", lw=0.5, zorder=1)
        ax.axvline(0, color="#E0E0E0", lw=0.5, zorder=1)
        ax.scatter(r * np.cos(w), r * np.sin(w), s=size(b),
                   c=palette(ds, idx), marker=marker(ds, idx),
                   edgecolors="white", linewidths=0.6, alpha=0.92, zorder=4)
        top = int(np.argmax(b))
        ax.scatter([r[top] * np.cos(w[top])], [r[top] * np.sin(w[top])],
                   s=size(b[top]) + 60, facecolors="none",
                   edgecolors="#333333", linewidths=0.8, zorder=5)
        ax.set_aspect("equal")
        ax.set_xlim(-1.15, 1.15); ax.set_ylim(-1.15, 1.15)
        ax.set_xticks([]); ax.set_yticks([])
        for s in ax.spines.values():
            s.set_visible(True); s.set_color("#CCCCCC"); s.set_linewidth(0.6)
        ax.set_title(display(ds), fontsize=9, pad=2)
    for j in range(len(rows), nrows * ncols):
        flat[j].axis("off")

    fig.suptitle(r"Per-dataset eigenvalue maps  "
                 r"(size $\propto|\beta_k|$,  $\circ$ = dominant mode)",
                 x=0.5, y=0.975, ha="center", fontsize=9.5)
    size_vals = legend_betas
    size_handles = [Line2D([0], [0], marker="o", color="none",
                           markerfacecolor="#888888", markeredgecolor="white",
                           markeredgewidth=0.5, markersize=np.sqrt(size(v)),
                           label=f"{v:.2f}") for v in size_vals]
    fig.legend(handles=size_handles, title=r"$|\beta_k|$", loc="lower center",
               ncol=3, bbox_to_anchor=(0.5, -0.01), fontsize=7, title_fontsize=7.5,
               handletextpad=0.4, columnspacing=1.4, framealpha=0.0)

    saved = [os.path.join(out_dir, f"fig_pole_facets.{e}") for e in ("pdf", "png")]
    for s in saved:
        fig.savefig(s)
    plt.close()
    return saved


# ============================================================================
#   figure 2: damped-oscillator bases
# ============================================================================
def fig_basis_all(ds_mean, out_dir):
    rows = row_order(ds_mean)
    K = len(ds_mean[rows[0]]["alpha"])
    t = np.linspace(0, 24, 400)
    cmap = plt.get_cmap("viridis")
    ncols = min(4, max(1, len(rows)))
    nrows = int(np.ceil(len(rows) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(1.8 * ncols, 1.85 * nrows),
                             sharex=True, sharey=True, squeeze=False)
    fig.subplots_adjust(left=0.065, right=0.90, top=0.85, bottom=0.115,
                        hspace=0.36, wspace=0.12)
    flat = axes.flat
    for idx, ds in enumerate(rows):
        ax = flat[idx]
        a = ds_mean[ds]["alpha"]; w = ds_mean[ds]["omega"]
        for k in range(K):
            ax.plot(t, np.exp(a[k] * t) * np.cos(w[k] * t),
                    lw=1.0, color=cmap(k / max(K - 1, 1)), alpha=0.9)
        slow = int(np.argmax(a))
        ax.plot(t,  np.exp(a[slow] * t), color="0.45", lw=0.7, ls="--")
        ax.plot(t, -np.exp(a[slow] * t), color="0.45", lw=0.7, ls="--")
        ax.axhline(0, color="0.85", lw=0.5)
        ax.set_xlim(0, 24); ax.set_ylim(-1.05, 1.05)
        ax.set_title(display(ds), fontsize=8)
        if idx % ncols == 0:
            ax.set_ylabel(r"$e^{\alpha_k t}\cos(\omega_k t)$")
        if idx >= len(rows) - ncols:
            ax.set_xlabel("time step $t$")
    for j in range(len(rows), nrows * ncols):
        flat[j].axis("off")

    cax = fig.add_axes([0.915, 0.13, 0.013, 0.72])
    sm = cm.ScalarMappable(norm=Normalize(0, max(K - 1, 1)), cmap=cmap)
    cbar = fig.colorbar(sm, cax=cax)
    cbar.set_label("mode index $k$", fontsize=8)
    cbar.set_ticks(range(K)); cbar.ax.tick_params(labelsize=7)
    fig.suptitle(r"Learned damped-oscillator basis  $e^{\alpha_k t}\cos(\omega_k t)$",
                 x=0.065, ha="left", fontsize=9, y=0.985)

    saved = [os.path.join(out_dir, f"fig_basis_all.{e}") for e in ("pdf", "png")]
    for s in saved:
        fig.savefig(s)
    plt.close()
    return saved


# ============================================================================
#   figure 3: alpha / omega heatmaps
# ============================================================================
def _matrix(ds_mean, key, rows):
    return np.vstack([ds_mean[ds][key] for ds in rows])


def _annotate(ax, M, fmt, thresh):
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            v = M[i, j]
            ax.text(j, i, fmt.format(v), ha="center", va="center",
                    fontsize=6.0, color=("white" if abs(v) > thresh else "0.25"))


def fig_heatmaps(ds_mean, out_dir):
    rows = row_order(ds_mean)
    K = len(ds_mean[rows[0]]["alpha"])
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 0.42 * len(rows) + 1.2))
    A = _matrix(ds_mean, "alpha", rows)
    W = _matrix(ds_mean, "omega", rows)
    ylabels = [display(r) for r in rows]
    xlabels = [f"$k_{{{i+1}}}$" for i in range(K)]

    ax = axes[0]
    im0 = ax.imshow(A, cmap=plt.get_cmap("Blues_r"), aspect="auto",
                    vmin=A.min(), vmax=0.0)
    ax.set_xticks(range(K)); ax.set_xticklabels(xlabels)
    ax.set_yticks(range(len(rows))); ax.set_yticklabels(ylabels)
    ax.set_title(r"(a)  Decay rate  $\alpha_k$", loc="left")
    ax.tick_params(length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    _annotate(ax, A, "{:.2f}", abs(A.min()) * 0.55 if A.min() < 0 else 1.0)
    cb0 = ax.figure.colorbar(im0, ax=ax, fraction=0.046, pad=0.03)
    cb0.set_label(r"$\alpha_k$ (more neg. $\Rightarrow$ faster)", fontsize=7)
    cb0.ax.tick_params(labelsize=7)

    ax = axes[1]
    wmax = np.abs(W).max() or 1.0
    im1 = ax.imshow(W, cmap="RdBu_r",
                    norm=TwoSlopeNorm(vmin=-wmax, vcenter=0.0, vmax=wmax),
                    aspect="auto")
    ax.set_xticks(range(K)); ax.set_xticklabels(xlabels)
    ax.set_yticks(range(len(rows))); ax.set_yticklabels(ylabels)
    ax.set_title(r"(b)  Angular frequency  $\omega_k$", loc="left")
    ax.tick_params(length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    _annotate(ax, W, "{:+.2f}", wmax * 0.55)
    cb1 = ax.figure.colorbar(im1, ax=ax, fraction=0.046, pad=0.03)
    cb1.set_label(r"$\omega_k$ (red $+$ / blue $-$)", fontsize=7)
    cb1.ax.tick_params(labelsize=7)

    plt.tight_layout()
    saved = [os.path.join(out_dir, f"fig_heatmaps.{e}") for e in ("pdf", "png")]
    for s in saved:
        fig.savefig(s)
    plt.close()
    return saved


ALL_FIGS = {
    "pole_spectrum": lambda dm, od, sz, lb: fig_pole_spectrum(dm, od, sz, lb),
    "pole_facets":   lambda dm, od, sz, lb: fig_pole_facets(dm, od, sz, lb),
    "basis":         lambda dm, od, sz, lb: fig_basis_all(dm, od),
    "heatmaps":      lambda dm, od, sz, lb: fig_heatmaps(dm, od),
}


def main():
    p = argparse.ArgumentParser(
        description="visualize the learned PhyTM physics spectrum")
    p.add_argument('--ckpt_dir', default='checkpoints_benchmark',
                   help='directory of *.pt checkpoints from run_benchmark.py')
    p.add_argument('--out_dir', default='.', help='directory for output figures')
    p.add_argument('--figs', default=",".join(ALL_FIGS),
                   help='comma-separated figures: ' + ",".join(ALL_FIGS))
    args = p.parse_args()

    ds_mean = collect(args.ckpt_dir)
    if not ds_mean:
        raise SystemExit(
            f"no usable checkpoints in '{args.ckpt_dir}'. Run run_benchmark.py "
            f"first (it saves <dataset>_M_sl<sl>_pl<pl>.pt there).")

    print(f"collected physics spectra for {len(ds_mean)} dataset(s): "
          f"{', '.join(row_order(ds_mean))}")
    set_style()
    os.makedirs(args.out_dir, exist_ok=True)
    bmin, bmax = _beta_range(ds_mean)
    size = _size_fn(bmin, bmax)
    legend_betas = _legend_betas(bmin, bmax)

    wanted = [f.strip() for f in args.figs.split(',') if f.strip()]
    for name in wanted:
        if name not in ALL_FIGS:
            print(f"  [skip] unknown figure {name!r}")
            continue
        saved = ALL_FIGS[name](ds_mean, args.out_dir, size, legend_betas)
        for s in saved:
            print("saved", s)


if __name__ == '__main__':
    main()
